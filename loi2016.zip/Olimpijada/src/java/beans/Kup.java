/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import java.util.Date;

/**
 *
 * @author Djordje
 */
public class Kup {
    int kup_id,tim1,tim2,poeni_tim1,poeni_tim2;
    String lokacija;
    Date termin;
    int takmicenje;
    int runda;

    public Kup(int kup_id, int tim1, int tim2, int poeni_tim1, int poeni_tim2, String lokacija, Date termin, int takmicenje, int runda) {
        this.kup_id = kup_id;
        this.tim1 = tim1;
        this.tim2 = tim2;
        this.poeni_tim1 = poeni_tim1;
        this.poeni_tim2 = poeni_tim2;
        this.lokacija = lokacija;
        this.termin = termin;
        this.takmicenje = takmicenje;
        this.runda= runda;
    }

    public int getRunda() {
        return runda;
    }

    public void setRunda(int runda) {
        this.runda = runda;
    }

    
    public int getKup_id() {
        return kup_id;
    }

    public void setKup_id(int kup_id) {
        this.kup_id = kup_id;
    }

    public int getTim1() {
        return tim1;
    }

    public void setTim1(int tim1) {
        this.tim1 = tim1;
    }

    public int getTim2() {
        return tim2;
    }

    public void setTim2(int tim2) {
        this.tim2 = tim2;
    }

    public int getPoeni_tim1() {
        return poeni_tim1;
    }

    public void setPoeni_tim1(int poeni_tim1) {
        this.poeni_tim1 = poeni_tim1;
    }

    public int getPoeni_tim2() {
        return poeni_tim2;
    }

    public void setPoeni_tim2(int poeni_tim2) {
        this.poeni_tim2 = poeni_tim2;
    }

    public String getLokacija() {
        return lokacija;
    }

    public void setLokacija(String lokacija) {
        this.lokacija = lokacija;
    }

    public Date getTermin() {
        return termin;
    }

    public void setTermin(Date termin) {
        this.termin = termin;
    }

    public int getTakmicenje() {
        return takmicenje;
    }

    public void setTakmicenje(int takmicenje) {
        this.takmicenje = takmicenje;
    }
    
    
           
    
}
