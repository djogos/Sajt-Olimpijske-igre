/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author Djordje
 */
public class Disciplina {
    int disciplina_id,sport,min_igraca,max_igraca;
    
    String naziv,vrsta;

    public Disciplina(int disciplina_id, int sport, String naziv, String vrsta, int min_igraca, int max_igraca) {
        this.disciplina_id = disciplina_id;
        this.sport = sport;
        this.min_igraca = min_igraca;
        this.max_igraca = max_igraca;
        this.naziv = naziv;
        this.vrsta = vrsta;
    }

    

    public int getDisciplina_id() {
        return disciplina_id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setDisciplina_id(int disciplina_id) {
        this.disciplina_id = disciplina_id;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public int getSport() {
        return sport;
    }

    public void setSport(int sport) {
        this.sport = sport;
    }

    public int getMin_igraca() {
        return min_igraca;
    }

    public void setMin_igraca(int min_igraca) {
        this.min_igraca = min_igraca;
    }

    public int getMax_igraca() {
        return max_igraca;
    }

    public void setMax_igraca(int max_igraca) {
        this.max_igraca = max_igraca;
    }

    public String getVrsta() {
        return vrsta;
    }

    public void setVrsta(String vrsta) {
        this.vrsta = vrsta;
    }
    
    
}
