/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author Djordje
 */
public class Sportista {
    int sportista_id;
    String ime, prezime;
    int zemlja;
    int sport;
    int disciplina;
    int medalja;
    String pol;

    public Sportista(int sportista_id, String ime, String prezime) {
        this.sportista_id = sportista_id;
        this.ime = ime;
        this.prezime = prezime;
    }

    public int getSportista_id() {
        return sportista_id;
    }

    public String getIme() {
        return ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setSportista_id(int sportista_id) {
        this.sportista_id = sportista_id;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }
    
    
    
    
}
