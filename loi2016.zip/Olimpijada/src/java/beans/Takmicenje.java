/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import java.util.Date;

/**
 *
 * @author Djordje
 */
public class Takmicenje {
    int takmicenje_id;
    String format;
    int sport,disciplina;
    String pol;
    Date datum_pocetka,datum_kraja;
    String lokacije;
    int delegat;
    String takmicari;

    public Takmicenje(int takmicenje_id, String format, int sport, int disciplina, String pol, Date datum_pocetka, Date datum_kraja, String lokacije, int delegat, String takmicari) {
        this.takmicenje_id = takmicenje_id;
        this.format=format;
        this.sport = sport;
        this.disciplina = disciplina;
        this.pol = pol;
        this.datum_pocetka = datum_pocetka;
        this.datum_kraja = datum_kraja;
        this.lokacije = lokacije;
        this.delegat = delegat;
        this.takmicari = takmicari;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }
    
    public int getTakmicenje_id() {
        return takmicenje_id;
    }

    public void setTakmicenje_id(int takmicenje_id) {
        this.takmicenje_id = takmicenje_id;
    }

    public int getSport() {
        return sport;
    }

    public void setSport(int sport) {
        this.sport = sport;
    }

    public int getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(int disciplina) {
        this.disciplina = disciplina;
    }

    public String getPol() {
        return pol;
    }

    public void setPol(String pol) {
        this.pol = pol;
    }

    public Date getDatum_pocetka() {
        return datum_pocetka;
    }

    public void setDatum_pocetka(Date datum_pocetka) {
        this.datum_pocetka = datum_pocetka;
    }

    public Date getDatum_kraja() {
        return datum_kraja;
    }

    public void setDatum_kraja(Date datum_kraja) {
        this.datum_kraja = datum_kraja;
    }

    public String getLokacije() {
        return lokacije;
    }

    public void setLokacije(String lokacije) {
        this.lokacije = lokacije;
    }

    public int getDelegat() {
        return delegat;
    }

    public void setDelegat(int delegat) {
        this.delegat = delegat;
    }

    public String getTakmicari() {
        return takmicari;
    }

    public void setTakmicari(String takmicari) {
        this.takmicari = takmicari;
    }
    
    
    
}
