/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author Djordje
 */
public class Korisnik {
    int korisnik_id;
    String korisnickoime,lozinka,ime,prezime;
    int drzava;
    String eposta;
    int tip;

    public Korisnik(String korisnickoime, String lozinka, String ime, String prezime, int drzava, String eposta, int tip) {
        this.korisnickoime = korisnickoime;
        this.lozinka = lozinka;
        this.ime = ime;
        this.prezime = prezime;
        this.drzava = drzava;
        this.eposta = eposta;
        this.tip = tip;
    }

    public Korisnik(int korisnik_id, String korisnickoime, String lozinka, String ime, String prezime, int drzava, String eposta, int tip) {
        this.korisnik_id = korisnik_id;
        this.korisnickoime = korisnickoime;
        this.lozinka = lozinka;
        this.ime = ime;
        this.prezime = prezime;
        this.drzava = drzava;
        this.eposta = eposta;
        this.tip = tip;
    }
    

    

    public String getKorisnickoime() {
        return korisnickoime;
    }

    public String getLozinka() {
        return lozinka;
    }

    public String getIme() {
        return ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public String getEposta() {
        return eposta;
    }

    public int getDrzava() {
        return drzava;
    }

    public int getTip() {
        return tip;
    }

    public void setKorisnickoime(String korisnickoime) {
        this.korisnickoime = korisnickoime;
    }

    public void setLozinka(String lozinka) {
        this.lozinka = lozinka;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public void setEposta(String eposta) {
        this.eposta = eposta;
    }

    public void setDrzava(int drzava) {
        this.drzava = drzava;
    }

    public void setTip(int tip) {
        this.tip = tip;
    }

    public int getKorisnik_id() {
        return korisnik_id;
    }

    public void setKorisnik_id(int korisnik_id) {
        this.korisnik_id = korisnik_id;
    }

    
    
    
    
}
