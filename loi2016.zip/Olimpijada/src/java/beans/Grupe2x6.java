/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import java.util.Date;

/**
 *
 * @author Djordje
 */
public class Grupe2x6 {
    int utakmica_id;
    String grupa,runda;
    int tim1,tim2,poeni_tim1,poeni_tim2,takmicenje;
    Date termin;
    String lokacija;

    public Grupe2x6(int utakmica_id, String grupa, String runda, int tim1, int tim2, int poeni_tim1, int poeni_tim2, int takmicenje, Date termin,String lokacija) {
        this.utakmica_id = utakmica_id;
        this.grupa = grupa;
        this.runda = runda;
        this.tim1 = tim1;
        this.tim2 = tim2;
        this.poeni_tim1 = poeni_tim1;
        this.poeni_tim2 = poeni_tim2;
        this.takmicenje = takmicenje; 
        this.termin = termin;
        this.lokacija=lokacija;
    }

    public String getLokacija() {
        return lokacija;
    }

    public void setLokacija(String lokacija) {
        this.lokacija = lokacija;
    }
    
    
    
    public int getUtakmica_id() {
        return utakmica_id;
    }

    public void setUtakmica_id(int utakmica_id) {
        this.utakmica_id = utakmica_id;
    }

    public String getGrupa() {
        return grupa;
    }

    public void setGrupa(String grupa) {
        this.grupa = grupa;
    }

    public String getRunda() {
        return runda;
    }

    public void setRunda(String runda) {
        this.runda = runda;
    }

    public int getTim1() {
        return tim1;
    }

    public void setTim1(int tim1) {
        this.tim1 = tim1;
    }

    public int getTim2() {
        return tim2;
    }

    public void setTim2(int tim2) {
        this.tim2 = tim2;
    }

    public int getPoeni_tim1() {
        return poeni_tim1;
    }

    public void setPoeni_tim1(int poeni_tim1) {
        this.poeni_tim1 = poeni_tim1;
    }

    public int getPoeni_tim2() {
        return poeni_tim2;
    }

    public void setPoeni_tim2(int poeni_tim2) {
        this.poeni_tim2 = poeni_tim2;
    }

    public int getTakmicenje() {
        return takmicenje;
    }

    public void setTakmicenje(int takmicenje) {
        this.takmicenje = takmicenje;
    }

    public Date getTermin() {
        return termin;
    }

    public void setTermin(Date termin) {
        this.termin = termin;
    }
    
    
    
    
}
