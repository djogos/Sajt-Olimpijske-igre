/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author Djordje
 */
public class Zemlja {
    int zemlja_id;
    String naziv;
    int zlato, srebro, bronza;
    int broj_takmicara;
    
    public Zemlja(int zemlja_id, String naziv, int zlato, int srebro, int bronza) {
        this.zemlja_id = zemlja_id;
        this.naziv = naziv;
        this.zlato = zlato;
        this.srebro = srebro;
        this.bronza = bronza;
    }

    public int getBroj_takmicara() {
        return broj_takmicara;
    }

    public void setBroj_takmicara(int broj_takmicara) {
        this.broj_takmicara = broj_takmicara;
    }

    
    public void setZemlja_id(int zemlja_id) {
        this.zemlja_id = zemlja_id;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public void setZlato(int zlato) {
        this.zlato = zlato;
    }

    public void setSrebro(int srebro) {
        this.srebro = srebro;
    }

    public void setBronza(int bronza) {
        this.bronza = bronza;
    }

    public int getZemlja_id() {
        return zemlja_id;
    }

    public String getNaziv() {
        return naziv;
    }

    public int getZlato() {
        return zlato;
    }

    public int getSrebro() {
        return srebro;
    }

    public int getBronza() {
        return bronza;
    }
    
    
    
    
    
}
