/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import java.util.Date;

/**
 *
 * @author Djordje
 */
public class Trka {
    int trka_id;
    int takmicenje;
    int ucesnik;
    Date termin;
    String lokacija;
    String rezultat;

    public Trka(int trka_id,int takmicenje, int ucesnik, Date termin, String lokacija, String rezultat) {
        this.trka_id = trka_id;
        this.takmicenje=takmicenje;
        this.ucesnik = ucesnik;
        this.termin = termin;
        this.lokacija = lokacija;
        this.rezultat = rezultat;
    }

    public int getTakmicenje() {
        return takmicenje;
    }

    public void setTakmicenje(int takmicenje) {
        this.takmicenje = takmicenje;
    }

    public int getTrka_id() {
        return trka_id;
    }

    public void setTrka_id(int trka_id) {
        this.trka_id = trka_id;
    }

    public int getUcesnik() {
        return ucesnik;
    }

    public void setUcesnik(int ucesnik) {
        this.ucesnik = ucesnik;
    }

    public Date getTermin() {
        return termin;
    }

    public void setTermin(Date termin) {
        this.termin = termin;
    }

    public String getLokacija() {
        return lokacija;
    }

    public void setLokacija(String lokacija) {
        this.lokacija = lokacija;
    }

    public String getRezultat() {
        return rezultat;
    }

    public void setRezultat(String rezultat) {
        this.rezultat = rezultat;
    }
    
    
}
