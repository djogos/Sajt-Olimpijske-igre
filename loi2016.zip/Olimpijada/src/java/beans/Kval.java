/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import java.util.Date;

/**
 *
 * @author Djordje
 */
public class Kval {
    int kval_id,takmicar;
    String rezultat,lokacija;
    Date termin;
    String grupa;
    int takmicenje,potvrda;
    

    public Kval(int kval_id, int takmicar, String rezultat, String lokacija, Date termin, String grupa, int takmicenje,int potvrda) {
        this.kval_id = kval_id;
        this.takmicar = takmicar;
        this.rezultat = rezultat;
        this.lokacija = lokacija;
        this.termin = termin;
        this.grupa = grupa;
        this.takmicenje = takmicenje;
        this.potvrda = potvrda;
    }

    public int getPotvrda() {
        return potvrda;
    }

    public void setPotvrda(int potvrda) {
        this.potvrda = potvrda;
    }

    
    
    public int getKval_id() {
        return kval_id;
    }

    public void setKval_id(int kval_id) {
        this.kval_id = kval_id;
    }

    public int getTakmicar() {
        return takmicar;
    }

    public void setTakmicar(int takmicar) {
        this.takmicar = takmicar;
    }

    public String getRezultat() {
        return rezultat;
    }

    public void setRezultat(String rezultat) {
        this.rezultat = rezultat;
    }

    public String getLokacija() {
        return lokacija;
    }

    public void setLokacija(String lokacija) {
        this.lokacija = lokacija;
    }

    public Date getTermin() {
        return termin;
    }

    public void setTermin(Date termin) {
        this.termin = termin;
    }

    public String getGrupa() {
        return grupa;
    }

    public void setGrupa(String grupa) {
        this.grupa = grupa;
    }

    public int getTakmicenje() {
        return takmicenje;
    }

    public void setTakmicenje(int takmicenje) {
        this.takmicenje = takmicenje;
    }
    
    
}
