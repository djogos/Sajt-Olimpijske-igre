/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author Djordje
 */
public class Sport {
    int sport_id;
    String naziv;

    public Sport(int sport_id, String naziv) {
        this.sport_id = sport_id;
        this.naziv = naziv;
    }

    
    
    
    
    public int getSport_id() {
        return sport_id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setSport_id(int sport_id) {
        this.sport_id = sport_id;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }
    
    
}
