/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author Djordje
 */
public class Rekord {
    String godina,mesto,disciplina,takmicar,zemlja,rekord;

    public Rekord(String godina, String mesto, String disciplina, String takmicar, String zemlja, String rekord) {
        this.godina = godina;
        this.mesto = mesto;
        this.disciplina = disciplina;
        this.takmicar = takmicar;
        this.zemlja = zemlja;
        this.rekord = rekord;
    }

    public String getGodina() {
        return godina;
    }

    public void setGodina(String godina) {
        this.godina = godina;
    }

    public String getMesto() {
        return mesto;
    }

    public void setMesto(String mesto) {
        this.mesto = mesto;
    }

    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }

    public String getTakmicar() {
        return takmicar;
    }

    public void setTakmicar(String takmicar) {
        this.takmicar = takmicar;
    }

    public String getZemlja() {
        return zemlja;
    }

    public void setZemlja(String zemlja) {
        this.zemlja = zemlja;
    }

    public String getRekord() {
        return rekord;
    }

    public void setRekord(String rekord) {
        this.rekord = rekord;
    }
    
    
}
