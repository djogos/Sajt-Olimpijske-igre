/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import java.util.Date;

/**
 *
 * @author Djordje
 */
public class Kval_pomocna_termini {
    String grupa;
    String lokacija;
    Date datum;

    public Kval_pomocna_termini(String grupa, String lokacija, Date datum) {
        this.grupa = grupa;
        this.lokacija = lokacija;
        this.datum = datum;
    }

    
    public String getGrupa() {
        return grupa;
    }

    public void setGrupa(String grupa) {
        this.grupa = grupa;
    }

    public String getLokacija() {
        return lokacija;
    }

    public void setLokacija(String lokacija) {
        this.lokacija = lokacija;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }
    
    
}
