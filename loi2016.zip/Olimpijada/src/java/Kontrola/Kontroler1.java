/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Kontrola;

import beans.Korisnik;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import util.DB;

/**
 *
 * @author Djordje
 */
@ManagedBean
@ApplicationScoped
public class Kontroler1 implements Serializable{
    
    
    String registracija_korisnik = "", registracija_lozinka="", registracija_potvrda="",registracija_ime,registracija_prezime,registracija_eposta,poruka_registracija;
    int registracija_zemlja,registracija_tip;
    String promena_korisnik, promena_stara, promena_nova = "", promena_potvrda = "", poruka_potvrda;

    public String getPromena_korisnik() {
        return promena_korisnik;
    }

    public void setPromena_korisnik(String promena_korisnik) {
        this.promena_korisnik = promena_korisnik;
    }

    public String getPromena_stara() {
        return promena_stara;
    }

    public void setPromena_stara(String promena_stara) {
        this.promena_stara = promena_stara;
    }

    public String getPromena_nova() {
        return promena_nova;
    }

    public void setPromena_nova(String promena_nova) {
        this.promena_nova = promena_nova;
    }

    public String getPromena_potvrda() {
        return promena_potvrda;
    }

    public void setPromena_potvrda(String promena_potvrda) {
        this.promena_potvrda = promena_potvrda;
    }

    public String getPoruka_potvrda() {
        return poruka_potvrda;
    }

    public void setPoruka_potvrda(String poruka_potvrda) {
        this.poruka_potvrda = poruka_potvrda;
    }
    
    
    public String registracija() {
        FacesContext context = FacesContext.getCurrentInstance();
        Connection c = DB.getInstance().getConnection();
        if (c == null) {

            poruka_registracija="Registracija nije uspela!!!(problem sa bazom podataka)Pokusajte kasnije!!!";
            context.addMessage(null, new FacesMessage("Poruka", poruka_registracija ) );
            return null;

        }
        if (!(registracija_potvrda.equals(registracija_lozinka))){
            poruka_registracija="Polja 'Lozinka' i 'Potvrda lozinke' moraju imati identicne vrednosti!!!";
            context.addMessage(null, new FacesMessage("Poruka", poruka_registracija ) );
            return null;
        } 
        if (!provera_lozinke(registracija_lozinka)){
        
            poruka_registracija="Lozinka mora imati 8-12 karaktera(1+ A-Z; 3+ a-z; 2+ 0-9; 2+ @#$%...), mora poceti slovom i ne sme imati vise od tri uzastopna karaktera!!!";
            context.addMessage(null, new FacesMessage("Poruka", poruka_registracija ) );
            return null;
        
        }
        try {
            if (registracija_tip == 2) {
                Statement st = c.createStatement();
                String upit = "select * from korisnik where drzava='" + registracija_zemlja + "' and tip=2;";
                ResultSet rs = st.executeQuery(upit);
                if (rs.next()) {
                    poruka_registracija = "Izabrana zemlja vec ima vodju delegacije!!!!";
                    context.addMessage(null, new FacesMessage("Poruka", poruka_registracija ) );
                    return null;

                }

            }
            Statement st = c.createStatement();
            String upit = "select * from korisnik where korisnickoime='"+registracija_korisnik+"';";
            ResultSet rs = st.executeQuery(upit);
            if (rs.next()){
                poruka_registracija="Korisnicko ime je zauzeto!!!";
                context.addMessage(null, new FacesMessage("Poruka", poruka_registracija ) );
                return null;
            }
            
            Statement st1=c.createStatement();
            String upit1="insert into korisnik (korisnickoime, lozinka, ime, prezime, drzava, eposta, tip) values ('"+registracija_korisnik+"','"+registracija_lozinka+"','"+registracija_ime+"','"+registracija_prezime+"','"+registracija_zemlja+"','"+registracija_eposta+"','"+registracija_tip+"');";
            st1.executeUpdate(upit1);
            poruka_registracija="Vas zahtev za registraciju je prihvacen!!!";
            context.addMessage(null, new FacesMessage("Poruka", poruka_registracija ) );
            return "pocetna";
        } catch (SQLException ex) {
            poruka_registracija = "Registracija nije uspela!!!(problem sa bazom podataka)Pokusajte kasnije!!!";
            context.addMessage(null, new FacesMessage("Poruka", poruka_registracija ) );
            return null;
        } finally {
            DB.getInstance().putConnection(c);
        }

    
    }
    public boolean provera_lozinke(String lozinka){
    
        int l=lozinka.length();
        if (!(l<=12 && l>8)){return false;}
        
        char c1=lozinka.charAt(0);
        if (!((c1>='a' && c1<='z' ) || (c1>='A' && c1<='Z' )) ){
        
            return false;
        }
        int veliko,malo,broj,spec;
        veliko=malo=broj=spec=0;
        for (int i = 0; i < l; i++) {
            char c = lozinka.charAt(i);
            String provera=""+c+c+c+c;
            if (lozinka.contains(provera)){
                return false;
            
            }
            if (c >= 'a' && c <= 'z') {
                malo++;
            } else if (c >= 'A' && c <= 'Z') {
                veliko++;
            } else if (c >= '0' && c <= '9') {
                broj++;
            } else {
                spec++;
            }

        }
        return veliko>=1 && malo>=3 && broj>=2 && spec>=2;
        
    }
    
    
    public String promena() {
        FacesContext context = FacesContext.getCurrentInstance();
        if (!(promena_nova.equals(promena_potvrda))) {

            poruka_potvrda = "Polja 'Nova lozinka' i 'Potvrda nove lozinke' moraju imati identicne vrednosti!!!";
            context.addMessage(null, new FacesMessage("Poruka",  poruka_potvrda) );
            return null;
        }
        if ((promena_nova.equals(promena_stara))) {
            poruka_potvrda = "Nova lozinka je identicna kao i stara!!!";
            context.addMessage(null, new FacesMessage("Poruka",  poruka_potvrda) );
            return null;

        }
        if (!(provera_lozinke(promena_nova))) {

            poruka_potvrda = "Lozinka mora imati 8-12 karaktera(1+ A-Z; 3+ a-z; 2+ 0-9; 2+ @#$%...), mora poceti slovom i ne sme imati vise od tri uzastopna karaktera!!!";
            context.addMessage(null, new FacesMessage("Poruka",  poruka_potvrda) );
            return null;

        }

        Connection c = DB.getInstance().getConnection();
        if (c == null) {

            poruka_potvrda = "Promena nije uspela. Problem sa bazom. Pokusajte kasnije!!!";
            context.addMessage(null, new FacesMessage("Poruka",  poruka_potvrda) );
            return null;

        }
        try {
            Statement st = c.createStatement();
            String upit = "select * from korisnik where korisnickoime='" + promena_korisnik + "';";
            ResultSet rs = st.executeQuery(upit);
            if (rs.next()) {
                if (rs.getString(3).equals(promena_stara)) {
                    Statement st1 = c.createStatement();
                    String upit1 = "UPDATE korisnik SET lozinka='"+promena_nova +"' WHERE korisnickoime='"+promena_korisnik+"' AND lozinka='"+promena_stara+"';";
                    st1.execute(upit1);
                    poruka_potvrda="Uspesno ste promenili lozinku!!!";
                    context.addMessage(null, new FacesMessage("Poruka",  poruka_potvrda) );
                    return null;
                } else {
                    poruka_potvrda = "Pogresna lozinka!!!";
                    context.addMessage(null, new FacesMessage("Poruka",  poruka_potvrda) );
                    return null;
                }
            } else {
                poruka_potvrda = "Ne postoji korisnik sa datim korisnickim imenom!!!";
                context.addMessage(null, new FacesMessage("Poruka",  poruka_potvrda) );
                return null;
            }

        } catch (SQLException ex) {
            poruka_potvrda = "Promena nije uspela. Problem sa bazom. Pokusajte kasnije!!!";
            context.addMessage(null, new FacesMessage("Poruka",  poruka_potvrda) );
            return null;
        } finally {
            DB.getInstance().putConnection(c);
        }

    }
    

    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public void setRegistracija_korisnik(String registracija_korisnik) {
        this.registracija_korisnik = registracija_korisnik;
    }

    public void setRegistracija_lozinka(String registracija_lozinka) {
        this.registracija_lozinka = registracija_lozinka;
    }

    public void setRegistracija_potvrda(String registracija_potvrda) {
        this.registracija_potvrda = registracija_potvrda;
    }

    public void setRegistracija_ime(String registracija_ime) {
        this.registracija_ime = registracija_ime;
    }

    public void setRegistracija_prezime(String registracija_prezime) {
        this.registracija_prezime = registracija_prezime;
    }

    public void setRegistracija_eposta(String registracija_eposta) {
        this.registracija_eposta = registracija_eposta;
    }

    public void setPoruka_registracija(String poruka_registracija) {
        this.poruka_registracija = poruka_registracija;
    }

    public void setRegistracija_zemlja(int registracija_zemlja) {
        this.registracija_zemlja = registracija_zemlja;
    }

    public void setRegistracija_tip(int registracija_tip) {
        this.registracija_tip = registracija_tip;
    }

    public String getRegistracija_korisnik() {
        return registracija_korisnik;
    }

    public String getRegistracija_lozinka() {
        return registracija_lozinka;
    }

    public String getRegistracija_potvrda() {
        return registracija_potvrda;
    }

    public String getRegistracija_ime() {
        return registracija_ime;
    }

    public String getRegistracija_prezime() {
        return registracija_prezime;
    }

    public String getRegistracija_eposta() {
        return registracija_eposta;
    }

    public String getPoruka_registracija() {
        return poruka_registracija;
    }

    public int getRegistracija_zemlja() {
        return registracija_zemlja;
    }

    public int getRegistracija_tip() {
        return registracija_tip;
    }
   
    
}
