/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Kontrola;

import beans.Disciplina;
import beans.Grupe2x6;
import beans.Korisnik;
import beans.Kup;
import beans.Kval;
import beans.Kval_pomocna_termini;
import beans.Pom_lista_tak_zem;
import beans.Pomocna_int_int;
import beans.Rekord;
import beans.Sport;
import beans.Sportista;
import beans.Takmicenje;
import beans.Trka;

import beans.Zemlja;
import java.io.Serializable;
import static java.lang.Math.ceil;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Random;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;


import javax.faces.event.ValueChangeEvent;
import javax.mail.search.IntegerComparisonTerm;
import javax.servlet.http.HttpSession;
import org.primefaces.model.DualListModel;
import org.primefaces.model.menu.DefaultMenuItem;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.MenuModel;
import util.DB;

/**
 *
 * @author Djordje
 */
@ManagedBean
@SessionScoped
public final class Kontroler implements Serializable {

    
    
    String korisnik, lozinka, poruka_logovanje;
    Korisnik trenutni_korisnik;
    List<Zemlja> zemlje,brojac;
    List<String> lokacije;
    List<Pom_lista_tak_zem> formati;
    List<Sport> sportovi;
    List<Disciplina> sport_extra;
    List<Disciplina> discipline;
    List<Rekord> rekordi;
    List<Sportista> sportisti_pretraga;
    String ime_prezime_pretraga,pol_pretraga="",poruka_pretraga;
    int zemlja_pretraga,sport_pretraga,disciplina_pretraga;
    boolean check_pretraga;
    
    
    
    
    String sportista_ime,sportista_prezime,poruka_sportista,sportista_pol="M";
    int sportista_sport;
    boolean sportista_render_disc;
    List<Disciplina> sportista_disciplina_za_izbor;
    int[] sportista_izabrane_discipline=new int[15];
    
    String organizator_novisport, poruka_organizator,organizator_disciplina_sport,organizator_disciplina_disciplina;
    String organizator_disciplina_tip,organizator_disciplina_max,organizator_disciplina_min;
    
    
    
    //Organizator
    List<Disciplina> organizator_tak_disciplina;
    int organizator_tak_disciplina_izabrana,organizator_tak_sport,delegat_organizator_tak;
    Date datum_pocetka_organizator_tak,datum_kraja_organizator_tak;
    String pol_organizator_tak="M",format_org_tak;
    DualListModel<Pom_lista_tak_zem> izbor_ucesnika_tak_organizator=new DualListModel<Pom_lista_tak_zem>();
    List<String> lokacija_org_tak;
    List<Korisnik> delegati_organizator_tak;
    boolean izbor_igraca_rend_org_tak=false,takmicari_takmicenje_izabrani=false;
    String takmicari_takmicenje;
    
    //Delegat
     boolean prvo_logovanje_delegat=true,zavrseno_takmicenje=false;
     List<Takmicenje> delegat_takmicenja;
     int trenutno_takmicenje_delegat;
     List<String> lokacije_delegat;
     Date delegat_datum;
     List<Pom_lista_tak_zem> ucesnici_delegat;
     Takmicenje trenutno_takmicenje_delegat_tak;
     String lokacija_trka_delegat;
     List<Integer> takmicari_int;
     boolean render_trka_delegat=true,zakazane_grupe_delegat=false,zakazane_grupe_delegat_visa_faza=false,visa_faza_grupe=false;
     List<Trka> lista_trka_delegat;
     List<Grupe2x6> grupaA_runda1,grupaB_runda1,grupaA_runda2,grupaB_runda2,grupaA_runda3,grupaB_runda3,grupaA_runda4,grupaB_runda4,grupaA_runda5,grupaB_runda5;
     List<Grupe2x6> Q_grupe, S_grupe,M_grupe;
     boolean[] trenutno_stanje_takmicenja=new boolean[10];
     
     
     //Delegat KUP
     boolean kup_ekipni,kup_zakazani_mecevi;
     List<Kup> kup_mecevi_16, kup_mecevi_8, kup_mecevi_4, kup_mecevi_2,kup_mecevi_1;
     
     
     //Delegat kvalifikacije
     int kval_broj_grupa;
     String kval_mask,kval_mask_naslov;
     boolean kval_zakazane_grupe,kval_zavrsene_kavlifikacije, kval_sto_manje;
     List<Kval_pomocna_termini> kval_termini_lokacije;
     List<List<Kval>> kval_grupe;
     List<Kval> kval_finale;
  
    //bread
    MenuModel model = null;
    DefaultMenuItem modelKucicia = null;
    DefaultMenuItem modelSport = null;
    DefaultMenuItem modelDisciplina = null;
    List<Pom_lista_tak_zem> modelDisciplina_lista;
    List<Pom_lista_tak_zem> modelSportisti_lista;
    List<Pom_lista_tak_zem> modelSportovi;
     
     //bread
    public void modelDohvatiSportiste(int sport, int disciplina){
        
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return;
            
        }
        
       String upit="select sportista_id, ime, prezime from sportisti where sport='"+sport+"', and zemlja='"+trenutni_korisnik.getDrzava()+"';";
       if (disciplina!=0){ 
           upit+=" and disciplina like '%,"+disciplina+",%';";
       }
       
       
         List<Pom_lista_tak_zem> ls=new ArrayList<Pom_lista_tak_zem>();
       
        try {
            Statement st=c.createStatement();
            
            ResultSet rs=st.executeQuery(upit);
            while(rs.next()){
                ls.add(new Pom_lista_tak_zem(rs.getInt(1), rs.getString(2)+" "+rs.getString(3)));
            
            
            }
            
            modelSportisti_lista=ls;
            
        } catch (SQLException ex) {
            
        } finally {
            DB.getInstance().putConnection(c);
        }
       
    }
    
    public void modelDohvatiDiscipline(int sport){
        
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return ;
            
        }
        
        List<Pom_lista_tak_zem> ls=new ArrayList<Pom_lista_tak_zem>();
        try {
            Statement st1=c.createStatement();
            String upit1="select extra_id from sport_extra where sport_id='"+sport+"';";
            ResultSet rs1=st1.executeQuery(upit1);
            while(rs1.next()){
                if (!nazivDiscipline(rs1.getInt(1)).equals("")){
                Statement st=c.createStatement();
                String upit="SELECT COUNT(*) FROM sportisti WHERE zemlja='"+trenutni_korisnik.getDrzava()+"' and disciplina like '%,"+rs1.getInt(1)+",%';";
                ResultSet rs=st.executeQuery(upit);
                rs.next();
                if (rs.getInt(1)>0){
                
                    ls.add(new Pom_lista_tak_zem(rs1.getInt(1), nazivDiscipline(rs1.getInt(1))+"["+rs.getInt(1)+"]"));
                }
                }
            }
             modelDisciplina_lista=ls;
            
            
            
        } catch (SQLException ex) {
           
        } finally {
            DB.getInstance().putConnection(c);
        }
        
    
    }
    
    
    public void prikaz_delegacije_sportovi(){

        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return ;
            
        }
        List<Pom_lista_tak_zem> ls=new ArrayList<Pom_lista_tak_zem>();
        try {
            Statement st=c.createStatement();
            String upit="SELECT sport_id,naziv,COUNT(*) FROM sportisti,sport WHERE zemlja='"+trenutni_korisnik.getDrzava()+"' and sport=sport.sport_id group BY sport";
            ResultSet rs=st.executeQuery(upit);
            while (rs.next()) {                
                ls.add(new Pom_lista_tak_zem(rs.getInt(1),rs.getString(2)+"["+rs.getInt(3)+"]"));
            }
            
        modelSportovi=ls;
            
        } catch (SQLException ex) {
           
        } finally {
            DB.getInstance().putConnection(c);
        }
        
    

    }
     
     
     public void kval_zavrsi_takmicenje(){
         FacesContext context = FacesContext.getCurrentInstance();
         Connection c = DB.getInstance().getConnection();
         if (c == null) {
            return;
            
        }
        try {
            Statement st1=c.createStatement();
            String upit1="select count(*) from kvalifikacije where takmicenje='"+trenutno_takmicenje_delegat+"' and grupa = '"+"F"+"' AND potvrda=0;";
            ResultSet rs1=st1.executeQuery(upit1);
            rs1.next();
            if (rs1.getInt(1)!=0){
                context.addMessage(null, new FacesMessage("Poruka:",  "Morate sacuvati rezultate svih takmicara!!!" ) );
                 return;
            
            }
            Statement stm1=c.createStatement();
            String upitstm1="select zavrseno from takmicenja where takmicenje_id='"+trenutno_takmicenje_delegat+"';";
            ResultSet rsstm1=stm1.executeQuery(upitstm1);
            rsstm1.next();
            if (rsstm1.getInt(1)!=0){
                context.addMessage(null, new FacesMessage("Poruka:",  "Takmicenje je vec zavrseno!!!" ) );
                 return;
                
            } 
            
             Statement st2=c.createStatement();
            String upit2="";
            if (kval_sto_manje){
                upit2="SELECT takmicar FROM kvalifikacije WHERE grupa<>'F' AND rezultat<>'' AND takmicenje='"+trenutno_takmicenje_delegat+"' ORDER BY rezultat ";
            } else{
                upit2="SELECT takmicar FROM kvalifikacije WHERE grupa<>'F' AND rezultat<>'' AND takmicenje='"+trenutno_takmicenje_delegat+"' ORDER BY rezultat DESC";
            }
            ResultSet rs2=st2.executeQuery(upit2);
            int i=0;
            int zlato=0, srebro=0, bronza=0;
            while(rs2.next()){
                if(i==0){zlato=rs2.getInt(1);}
                if(i==1){srebro=rs2.getInt(1);}
                if(i==2){bronza=rs2.getInt(1); break;}
                i++;
            }
            if (zlato !=0){
                Statement stzlato=c.createStatement();
                Statement stzlato1=c.createStatement();
                String upitzlato = "update zemlje set zlato=zlato+1 where zemlja_id='" + dohvati_zemlju_takmicara(zlato) + "';";
                String upitzlato1="update sportisti set medalja=medalja+1 where sportista_id='" + zlato + "';";
                stzlato.execute(upitzlato);
                stzlato1.execute(upitzlato1);
            }    
            if (srebro !=0){
                Statement stsrebro=c.createStatement();
                Statement stsrebro1=c.createStatement();
                String upitsrebro = "update zemlje set srebro=srebro+1 where zemlja_id='" + dohvati_zemlju_takmicara(srebro) + "';";
                String upitsrebro1="update sportisti set medalja=medalja+1 where sportista_id='" + srebro + "';";
                stsrebro.execute(upitsrebro);
                stsrebro1.execute(upitsrebro1);
            }     
             if (bronza !=0){
                Statement stbronza=c.createStatement();
                Statement stbronza1=c.createStatement();
                String upitbronza = "update zemlje set bronza=bronza+1 where zemlja_id='" + dohvati_zemlju_takmicara(bronza) + "';";
                String upitbronza1="update sportisti set medalja=medalja+1 where sportista_id='" + bronza + "';";
                stbronza.execute(upitbronza);
                stbronza1.execute(upitbronza1);
            }   
            
            
            Statement stm2=c.createStatement();
            String upitstm2="update takmicenja set zavrseno='1' where takmicenje_id='"+trenutno_takmicenje_delegat+"';";
            stm2.execute(upitstm2);
            
            } catch (SQLException ex) {
            
        } finally {
            DB.getInstance().putConnection(c);
        }
     
     }
     
     public void kval_potvrda_kvalifikacija(){
         
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return;
            
        }
        FacesContext context = FacesContext.getCurrentInstance();
        try {
            Statement st1=c.createStatement();
            String upit1="select count(*) from kvalifikacije where takmicenje='"+trenutno_takmicenje_delegat+"' and grupa <> '"+"F"+"' AND potvrda=0;";
            ResultSet rs1=st1.executeQuery(upit1);
            rs1.next();
            if (rs1.getInt(1)!=0){
                context.addMessage(null, new FacesMessage("Poruka:",  "Morate izabrati sacuvati rezultate svih takmicara!!!" ) );
                 return;
            
            }
            Statement st2=c.createStatement();
            String upit2="";
            if (kval_sto_manje){
                upit2="SELECT takmicar FROM kvalifikacije WHERE grupa<>'F' AND rezultat<>'' AND takmicenje='"+trenutno_takmicenje_delegat+"' ORDER BY rezultat ";
            } else{
                upit2="SELECT takmicar FROM kvalifikacije WHERE grupa<>'F' AND rezultat<>'' AND takmicenje='"+trenutno_takmicenje_delegat+"' ORDER BY rezultat DESC";
            }
            ResultSet rs2=st2.executeQuery(upit2);
            int i=0;
            while(rs2.next()){
               int id=kval_finale.get(i).getKval_id();
               kval_finale.get(i).setTakmicar(rs2.getInt(1));
               Statement st3=c.createStatement();
               String upit3="update kvalifikacije set takmicar='"+rs2.getInt(1)+"' where kval_id='"+id+"';";
               st3.execute(upit3);
               i++;
               if (i==8){
                   break;
               }
            }
            if(i!=8 && kval_finale.size()==8){
                
                for(int j=i; j<8; j++){
                    int id=kval_finale.get(i).getKval_id();
                    kval_finale.remove(i);
                    Statement st4=c.createStatement();
                    String upit4="DELETE FROM kvalifikacije WHERE kval_id='"+id+"';";
                    st4.execute(upit4);
                }
            }
            kval_zavrsene_kavlifikacije=true;
            
            
        } catch (SQLException ex) {
            
        } finally {
            DB.getInstance().putConnection(c);
        }
     
     
     }
     
     public void kval_sacuvaj_rezultate(int id,String grupa,String rezultat){
     
         
        
         if (grupa.equals("F")) {
             for(Kval tak:kval_finale){
                 if(tak.getKval_id()==id){
                     tak.setPotvrda(1);
                     break;
                 }
             
             }
         } else {
             int pozicija;
             pozicija = Integer.parseInt(grupa) - 1;

             for (Kval tak : kval_grupe.get(pozicija)) {
                 if (tak.getKval_id() == id) {
                     tak.setPotvrda(1);
                     break;
                 }
             }
         }
         Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return;
            
        }
       
        try {
            Statement st=c.createStatement();
            String upit="update kvalifikacije set potvrda=1, rezultat='"+rezultat+"' where kval_id='"+id+"';";
            st.execute(upit);
           
            
            
            
        } catch (SQLException ex) {
            
        } finally {
            DB.getInstance().putConnection(c);
        }
         
     
     }
     
     public void kval_prikaz(){
     
         if (!kval_zakazane_grupe){
             kval_termini_lokacije=new ArrayList<Kval_pomocna_termini>();
             
             if (kval_broj_grupa>1){
              
                 for(int j=1; j<=kval_broj_grupa; j++)
                    kval_termini_lokacije.add(new Kval_pomocna_termini(Integer.toString(j), null, null));
             }
             kval_termini_lokacije.add(new Kval_pomocna_termini("F", null, null));
             
        }
         

             Connection c = DB.getInstance().getConnection();
             if (c == null) {
                 return;

             }

             try {
                 kval_grupe = new ArrayList<List<Kval>>();
                 if (kval_broj_grupa>1){
                 for (int i = 1; i <= kval_broj_grupa; i++) {
                     Statement st = c.createStatement();
                     String upit = "select * from kvalifikacije where grupa='"+i+"' and takmicenje='"+trenutno_takmicenje_delegat+"';";
                     ResultSet rs = st.executeQuery(upit);
                     List<Kval> l1=new ArrayList<Kval>();
                     while (rs.next()){
                        l1.add(new Kval(rs.getInt(1), rs.getInt(2), rs.getString(3), rs.getString(4),rs.getDate(5)==null?null: new Date(rs.getDate(5).getTime()), rs.getString(6), rs.getInt(7),rs.getInt(8)));
                     }
                     kval_grupe.add(l1);
                 }
                 }
                 Statement st = c.createStatement();
                 String upit = "select * from kvalifikacije where grupa='" + "F" + "' and takmicenje='" + trenutno_takmicenje_delegat + "';";
                 ResultSet rs = st.executeQuery(upit);
                 List<Kval> l1 = new ArrayList<Kval>();

                 while (rs.next()) {
                     l1.add(new Kval(rs.getInt(1), rs.getInt(2), rs.getString(3), rs.getString(4),rs.getDate(5)==null?null: new Date(rs.getDate(5).getTime()), rs.getString(6), rs.getInt(7),rs.getInt(8)));
                 }
                 kval_finale=new ArrayList<Kval>(l1);
                 
                  if (kval_zavrsene_kavlifikacije) {
                     kval_potvrda_kvalifikacija();
                 }
                
             } catch (SQLException ex) {

             } finally {
                 DB.getInstance().putConnection(c);
             }
         
         
     
     
     }
     
     public void kval_trenutna_faza(){
         
         Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return;
            
        }
       
        try {
            Statement st=c.createStatement();
            String upit="SELECT COUNT(*) FROM kvalifikacije WHERE termin IS null and takmicenje='"+trenutno_takmicenje_delegat+"';";
            ResultSet rs=st.executeQuery(upit);
            rs.next();
            kval_zakazane_grupe = rs.getInt(1)==0;
            
            Statement st1=c.createStatement();
            String upit1="SELECT COUNT(*) FROM kvalifikacije WHERE potvrda=0 and grupa<> 'F' and takmicenje='"+trenutno_takmicenje_delegat+"';";
            ResultSet rs1=st1.executeQuery(upit1);
            rs1.next();
            kval_zavrsene_kavlifikacije=rs1.getInt(1)==0;
            
            
            
        } catch (SQLException ex) {
            
        } finally {
            DB.getInstance().putConnection(c);
        }
     
     
     }
     
     
     public void kval_zakazi_termine(){
         
         for(Kval_pomocna_termini term:kval_termini_lokacije){
             if(term.getDatum()==null){
                  FacesContext context = FacesContext.getCurrentInstance();
                  context.addMessage(null, new FacesMessage("Poruka",  "Morate izabrati sve termine!!!" ) );
                  return;
             }
         
         }
         
        FacesContext context = FacesContext.getCurrentInstance(); 
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            //nije uspelo
            return;
            
        }
        
        try {
            int i=0;
            for(Kval_pomocna_termini term:kval_termini_lokacije){
                for(int j=0; j<=i-1 ; j++)
                {
                    if(term.getDatum().getTime()==kval_termini_lokacije.get(j).getDatum().getTime() && term.getLokacija().equals(kval_termini_lokacije.get(j).getLokacija())){
                        context.addMessage(null, new FacesMessage("Poruka:",  "Pokusaj da se na lokaciji "+term.getLokacija()+" zakaze vise dogadjaja u terminu "+term.getDatum()+" !!!" ) );
                        return;
                    }
                }
                i++;
                Statement st=c.createStatement();
                String upit="select termin from kvalifikacije where lokacija='"+term.getLokacija()+"';" ;
                ResultSet rs=st.executeQuery(upit);
                while (rs.next()) {                    
                    if (rs.getDate(i).getTime()==term.getDatum().getTime()){
                    context.addMessage(null, new FacesMessage("Poruka:",  "Pokusaj da se na lokaciji "+term.getLokacija()+" zakaze vise dogadjaja u terminu "+term.getDatum()+" !!!" ) );
                    return;
                
                }
                }
                
            }
            for(Kval_pomocna_termini term:kval_termini_lokacije){
                Statement st=c.createStatement();
                String upit="update kvalifikacije set lokacija='"+term.getLokacija()+"', termin='"+new java.sql.Date(term.getDatum().getTime())+"' where grupa='"+term.getGrupa()+"';";
                st.execute(upit);
            }
           kval_zakazane_grupe=true;
           kval_prikaz();
                
        } catch (SQLException e) {
             e.printStackTrace(System.err);
                System.err.println("SQLState: " +
                    ((SQLException)e).getSQLState());

                System.err.println("Error Code: " +
                    ((SQLException)e).getErrorCode());

                System.err.println("Message: " + e.getMessage()); e.printStackTrace(System.err);
                System.err.println("SQLState: " +
                    ((SQLException)e).getSQLState());

                System.err.println("Error Code: " +
                    ((SQLException)e).getErrorCode());

                System.err.println("Message: " + e.getMessage());
        } finally {
            DB.getInstance().putConnection(c);
        }
         
         
         
         
         
         
     
     } 
     
     //KVAL inicijalizacija
     public String kval_inicijalizacija(){
         Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return null;
            
        }
       kval_broj_grupa=(int) ceil(takmicari_int.size()/8.);
       switch (nazivDiscipline(trenutno_takmicenje_delegat_tak.getDisciplina())){
                
                    case "100 metara trcanje":
                    case "200 metara trcanje":
                    case "400 metara trcanje": {kval_mask="99,99"; kval_mask_naslov="SS,TT"; kval_sto_manje=true; break;}
                    case "800 metara trcanje":
                    case "5000 metara trcanje":
                    case "10000 metara trcanje": {kval_mask="99:99:99"; kval_mask_naslov="MM:SS,TT"; kval_sto_manje=true; break;}
                    case "skok u vis":
                    case "skok u dalj":
                    case "troskok":
                    case "skok s motkom": {kval_mask="9,99"; kval_mask_naslov="M,CM"; kval_sto_manje=false; break;}
                    case "bacanje kugle":
                    case "bacanje diska":
                    case "bacanje koplja":
                    case "bacanje kladiva": {kval_mask="99,99"; kval_mask_naslov="MM,CM"; kval_sto_manje=false; break;}
                    case "maraton":
                    case "20km brzo hodanje":
                    case "50km brzo hodanje": {kval_mask="99:99:99"; kval_mask_naslov="HH:MM:SS"; kval_sto_manje=true; break;}
                    case "50m trostav":
                    case "10m vazdusna puska":
                    case "25m malokalibarski pistolj":
                    case "10m vazdusni pistolj": {kval_mask="99"; kval_mask_naslov="krugovi"; kval_sto_manje=false; break;}
                   
                    //mogu da se ubace maraton i hodanja
                    
                }
        try {
            Statement st=c.createStatement();
            String upit="select * from kvalifikacije where takmicenje='"+trenutno_takmicenje_delegat+"';";
            ResultSet rs=st.executeQuery(upit);
            if (!rs.next()){
                
                
                long seed=System.nanoTime();
                Collections.shuffle(takmicari_int, new Random(seed));
                if (takmicari_int.size()>8){
                int j=1;
                int i=0;
                for(int tak:takmicari_int){
                    
                    Statement st1=c.createStatement();
                    String upit1="insert into kvalifikacije (takmicar,grupa,takmicenje) values ('"+tak+"','"+j+"','"+trenutno_takmicenje_delegat+"');";
                    st1.executeUpdate(upit1);
                    i++;
                    if (i==8){
                        j++;
                        i=0;
                    }
                }
                
                for(int k=0; k<8; k++){
                    Statement st1=c.createStatement();
                    String upit1="insert into kvalifikacije (grupa,takmicenje) values ('"+"F"+"','"+trenutno_takmicenje_delegat+"');";
                    st1.executeUpdate(upit1);
                
                }
                }else {
                    
                    for(int tak:takmicari_int){
                
                        Statement st1 = c.createStatement();
                        String upit1 = "insert into kvalifikacije (takmicar,grupa,takmicenje) values ('" + tak + "','" + "F" + "','" + trenutno_takmicenje_delegat + "');";
                        st1.executeUpdate(upit1);
                    }
                
                }
                
                
            
            }
            return null;
            
            
        } catch (SQLException ex) {
            return null;
        } finally {
            DB.getInstance().putConnection(c);
        }
     
     
     
     }
     
     
     
     //KUP
     
     //KUP kraj takmicenja
     
     public void kup_zavrsi_takmicenje(){
         
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            //potvrda nije uspela
            return ;
            
        }
       
       
        try {
            Statement stm1=c.createStatement();
            String upitstm1="select zavrseno from takmicenja where takmicenje_id='"+trenutno_takmicenje_delegat+"';";
            ResultSet rsstm1=stm1.executeQuery(upitstm1);
            rsstm1.next();
            if (rsstm1.getInt(1)!=0){
                
                zavrseno_takmicenje=true;
                return;
            }            
            int zlato, srebro, bronza;
            if(kup_mecevi_1.get(1).getPoeni_tim1()>kup_mecevi_1.get(1).getPoeni_tim2()){
                zlato=kup_mecevi_1.get(1).getTim1();
                srebro=kup_mecevi_1.get(1).getTim2();
            }
            else {
                zlato=kup_mecevi_1.get(1).getTim2();
                srebro=kup_mecevi_1.get(1).getTim1();
            }
            bronza=kup_mecevi_1.get(0).getPoeni_tim1()>kup_mecevi_1.get(0).getPoeni_tim2()? kup_mecevi_1.get(0).getTim1():kup_mecevi_1.get(0).getTim2();
            
            if (kup_ekipni) {

                Statement st1 = c.createStatement();
                Statement st2 = c.createStatement();
                Statement st3 = c.createStatement();
                String upit1 = "update zemlje set zlato=zlato+1 where zemlja_id='" + zlato + "';";
                String upit2 = "update zemlje set srebro=srebro+1 where zemlja_id='" + srebro + "';";
                String upit3 = "update zemlje set bronza=bronza+1 where zemlja_id='" + bronza + "';";
                st1.execute(upit1);
                st2.execute(upit2);
                st3.execute(upit3);

                Statement st = c.createStatement();
                String upit = "update sportisti set medalja=medalja+1 where sport='" + trenutno_takmicenje_delegat_tak.getSport() + "' and pol='" + trenutno_takmicenje_delegat_tak.getPol() + "' and (zemlja='" + zlato + "' or zemlja='" + srebro + "' or zemlja='" + bronza + "');";
                st.execute(upit);

            } else{
                
                Statement st1 = c.createStatement();
                Statement st2 = c.createStatement();
                Statement st3 = c.createStatement();
                String upit1 = "update zemlje set zlato=zlato+1 where zemlja_id='" + dohvati_zemlju_takmicara(zlato) + "';";
                String upit2 = "update zemlje set srebro=srebro+1 where zemlja_id='" + dohvati_zemlju_takmicara(srebro) + "';";
                String upit3 = "update zemlje set bronza=bronza+1 where zemlja_id='" + dohvati_zemlju_takmicara(bronza) + "';";
                st1.execute(upit1);
                st2.execute(upit2);
                st3.execute(upit3);
            
                Statement st = c.createStatement();
                String upit = "update sportisti set medalja=medalja+1 where (sportista_id='" + zlato + "' or sportista_id='" + srebro + "' or sportista_id='" + bronza + "');";
                st.execute(upit);
            
            }
            Statement stm2=c.createStatement();
            String upitstm2="update takmicenja set zavrseno='1' where takmicenje_id='"+trenutno_takmicenje_delegat+"';";
            stm2.execute(upitstm2);
            zavrseno_takmicenje=true;
            
            
        } catch (SQLException ex) {
            //nije uspelo
            
        } finally {
            DB.getInstance().putConnection(c);
        }
         
     
     }
     
     //KUP potvrda runde
     public void kup_potvrdi_rundu(List<Kup> mecevi,List<Kup> naredna, int r1, int r2){
     
         FacesContext context = FacesContext.getCurrentInstance();
         for (Kup mec:mecevi){
             if (mec.getPoeni_tim1()==mec.getPoeni_tim2()){
                 context.addMessage(null, new FacesMessage("Poruka:",  "Rezultat utakmice "+(kup_ekipni? nazivZemlje(mec.getTim1()) : imeSportiste(mec.getTim1()))+" - "+(kup_ekipni? nazivZemlje(mec.getTim2()) : imeSportiste(mec.getTim2()))+" ne sme biti neresen!!!" ) );
                 return;
             }
             
         
         }
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            //PORUKA NIJE USPELO DODAVANJE
            return;
            
        }
       
        try {
            for(Kup mec:mecevi){
                Statement st1=c.createStatement();
                String upit1="update kup set poeni_tim1='"+mec.getPoeni_tim1()+"', poeni_tim2='"+mec.getPoeni_tim2()+"' where kup_id='"+mec.getKup_id()+"';";
                st1.execute(upit1);
         
         }
         if(r2==5){
             Kup mec1, mec2;
             mec1=mecevi.get(0);
             mec2=mecevi.get(1);
             kup_mecevi_1.get(0).setTim1(mec1.getPoeni_tim1()<mec1.getPoeni_tim2()? mec1.getTim1(): mec1.getTim2());
             kup_mecevi_1.get(0).setTim2(mec2.getPoeni_tim1()<mec2.getPoeni_tim2()? mec2.getTim1(): mec2.getTim2());
            
             
             kup_mecevi_1.get(1).setTim1(mec1.getPoeni_tim1()>mec1.getPoeni_tim2()? mec1.getTim1(): mec1.getTim2());
             kup_mecevi_1.get(1).setTim2(mec2.getPoeni_tim1()>mec2.getPoeni_tim2()? mec2.getTim1(): mec2.getTim2());
            
             Statement st1=c.createStatement();
             String upit1 = "update kup set tim1='"+kup_mecevi_1.get(0).getTim1()+"', tim2='"+kup_mecevi_1.get(0).getTim2()+"' where kup_id='"+kup_mecevi_1.get(0).getKup_id()+"';";
             st1.execute(upit1);
             Statement st2=c.createStatement();
             String upit2 = "update kup set tim1='"+kup_mecevi_1.get(1).getTim1()+"', tim2='"+kup_mecevi_1.get(1).getTim2()+"' where kup_id='"+kup_mecevi_1.get(1).getKup_id()+"';";
             st2.execute(upit2);
             
            } else if (naredna != null) {
                for (int i = 0; i < mecevi.size(); i++) {
                    if (i % 2 == 0) {
                        naredna.get(i / 2).setTim1(mecevi.get(i).getPoeni_tim1() > mecevi.get(i).getPoeni_tim2() ? mecevi.get(i).getTim1() : mecevi.get(i).getTim2());
                    } else {
                        naredna.get(i / 2).setTim2(mecevi.get(i).getPoeni_tim1() > mecevi.get(i).getPoeni_tim2() ? mecevi.get(i).getTim1() : mecevi.get(i).getTim2());

                    }
             }
             for (Kup mec : naredna) {
                 Statement st1 = c.createStatement();
                 String upit1 = "update kup set tim1='" + mec.getTim1() + "', tim2='" + mec.getTim2() + "' where kup_id='" + mec.getKup_id() + "';";
                 st1.execute(upit1);

             }
                
            } else {trenutno_stanje_takmicenja[0]=false;}


            
            
           trenutno_stanje_takmicenja[r1]=false;
           trenutno_stanje_takmicenja[r2]=true;
           
         } catch (SQLException ex) {
            //PORUKA NIJE USPELO
        } finally {
            DB.getInstance().putConnection(c);
        }
     
     
     }
     
     
     //KUP zakazivanje meceva
     public void kup_zakazi_meceve(){
         
         
         List<Kup> pomocna=new ArrayList<Kup>(kup_mecevi_16);
         pomocna.addAll(kup_mecevi_8);
         pomocna.addAll(kup_mecevi_4);
         pomocna.addAll(kup_mecevi_2);
         pomocna.addAll(kup_mecevi_1);
         
         FacesContext context = FacesContext.getCurrentInstance();
         
         for(Kup mec:pomocna){
             if (mec.getTermin()==null){
                 context.addMessage(null, new FacesMessage("Poruka:",  "Morate izabrati termine svih meceva!!!" ) );
                 return;
             }
             
         }
         
         
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return;
            
        }
        
        try {
            int i=0;
            for(Kup mec:pomocna){
                for(int j=0; j<=i-1 ; j++)
                {
                    if(mec.getTermin().getTime()==pomocna.get(j).getTermin().getTime() && mec.getLokacija().equals(pomocna.get(j).getLokacija())){
                        context.addMessage(null, new FacesMessage("Poruka:",  "Pokusaj da se na lokaciji "+mec.getLokacija()+" zakaze vise meceva u terminu "+mec.getTermin()+" !!!" ) );
                        return;
                    }
                }
                i++;
                Statement st=c.createStatement();
                String upit="select termin from kup where lokacija='"+mec.getLokacija()+"';" ;
                ResultSet rs=st.executeQuery(upit);
                while (rs.next()) {                    
                    if (rs.getTime(1).getTime()==mec.getTermin().getTime()){
                    context.addMessage(null, new FacesMessage("Poruka:",  "Pokusaj da se na lokaciji "+mec.getLokacija()+" zakaze vise meceva u terminu "+mec.getTermin()+" !!!" ) );
                    return;
                
                }
                }
                
            }
            for(Kup mec:pomocna){
                Statement st=c.createStatement();
                String upit="update kup set lokacija='"+mec.getLokacija()+"', termin='"+new java.sql.Date(mec.getTermin().getTime())+"' where kup_id='"+mec.getKup_id()+"';";
                st.execute(upit);
            }
           kup_zakazani_mecevi=true;
           kup_odredi_trenutno_stanje();
           
                
        } catch (SQLException e) {
             e.printStackTrace(System.err);
                System.err.println("SQLState: " +
                    ((SQLException)e).getSQLState());

                System.err.println("Error Code: " +
                    ((SQLException)e).getErrorCode());

                System.err.println("Message: " + e.getMessage()); e.printStackTrace(System.err);
                System.err.println("SQLState: " +
                    ((SQLException)e).getSQLState());

                System.err.println("Error Code: " +
                    ((SQLException)e).getErrorCode());

                System.err.println("Message: " + e.getMessage());
        } finally {
            DB.getInstance().putConnection(c);
        }
     
        
        
     }
     
    //KUP odredi trenutno stanje (trenutno_stanje_takmicenja[])
     public String kup_odredi_trenutno_stanje(){
         
         zavrseno_takmicenje=false;
         
         
         int br=takmicari_int.size()/2;
         trenutno_stanje_takmicenja[0] = true;
         trenutno_stanje_takmicenja[1] = true;
         trenutno_stanje_takmicenja[2] = false;
         trenutno_stanje_takmicenja[3] = false;
         trenutno_stanje_takmicenja[4] = false;
         if (br == 4) {
             trenutno_stanje_takmicenja[2]=true;
             trenutno_stanje_takmicenja[3]=false;
             trenutno_stanje_takmicenja[4]=false;
         }
         if(br==8){
             trenutno_stanje_takmicenja[2]=true;
             trenutno_stanje_takmicenja[3]=true;
             trenutno_stanje_takmicenja[4]=false;
         }
         if(br==16){
             trenutno_stanje_takmicenja[2]=true;
             trenutno_stanje_takmicenja[3]=true;
             trenutno_stanje_takmicenja[4]=true;
         }
         if (prvo_logovanje_delegat){return null;}
         Connection c = DB.getInstance().getConnection();
         if (c == null) {
             return null;
         }
         try {
            Statement st=c.createStatement();
            String upit="SELECT COUNT(*) FROM kup WHERE termin IS null and takmicenje='"+trenutno_takmicenje_delegat+"';";
            ResultSet rs=st.executeQuery(upit);
            rs.next();
            kup_zakazani_mecevi = rs.getInt(1)==0;
            
            Statement st1=c.createStatement();
            String upit1="SELECT * FROM kup WHERE poeni_tim1 IS null AND poeni_tim2 IS null AND takmicenje='"+trenutno_takmicenje_delegat+"';";
            ResultSet rs1=st1.executeQuery(upit1);
            for(int i=5; i<10; i++){
                trenutno_stanje_takmicenja[i]=false;
            } 
            if (!rs1.next()) {
                 Statement stm1 = c.createStatement();
                 String upitstm1 = "select zavrseno from takmicenja where takmicenje_id='" + trenutno_takmicenje_delegat + "';";
                 ResultSet rsstm1 = stm1.executeQuery(upitstm1);
                 rsstm1.next();
                 zavrseno_takmicenje=rsstm1.getInt(1) != 0; 
                 trenutno_stanje_takmicenja[0]=false;
                 return null;
                
            }
            
            switch (rs1.getString("runda")){
                case "1":{ trenutno_stanje_takmicenja[5]=true; break;}
                case "2":{ trenutno_stanje_takmicenja[6]=true; break;}
                case "4":{ trenutno_stanje_takmicenja[7]=true; break;}
                case "8":{ trenutno_stanje_takmicenja[8]=true; break;}
                case "16":{ trenutno_stanje_takmicenja[9]=true; break;}
                
            }
            
            
            return null;
            
            
        } catch (SQLException ex) {
            return null;
        } finally {
            DB.getInstance().putConnection(c);
        }    
             
             
         
     
     }
     
    //KUP prikazi raspored
     public void kup_prikazi_raspored(){
         if (!prvo_logovanje_delegat){
             
             
             Connection c = DB.getInstance().getConnection();
             if (c == null) {
                 return;

             }

             try {
             
             
             kup_mecevi_1 = new ArrayList<Kup>();
             kup_mecevi_2 = new ArrayList<Kup>();
             kup_mecevi_4 = new ArrayList<Kup>();
             kup_mecevi_8 = new ArrayList<Kup>();
             kup_mecevi_16 = new ArrayList<Kup>();
                 for (int i = 1; i <= 16; i = i * 2) {
                     Statement st = c.createStatement();
                     String upit = "select * from kup where runda='"+i+"';";
                     ResultSet rs = st.executeQuery(upit);
                     while(rs.next()){
                     switch (i){
                         case 1:{kup_mecevi_1.add(new Kup(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getInt(5), rs.getString(6), rs.getDate(7)==null? null: new Date(rs.getDate(7).getTime()), rs.getInt(8), i)); break;}
                         case 2:{kup_mecevi_2.add(new Kup(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getInt(5), rs.getString(6), rs.getDate(7)==null? null: new Date(rs.getDate(7).getTime()), rs.getInt(8), i)); break;}
                         case 4:{kup_mecevi_4.add(new Kup(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getInt(5), rs.getString(6), rs.getDate(7)==null? null: new Date(rs.getDate(7).getTime()), rs.getInt(8), i)); break;}
                         case 8:{kup_mecevi_8.add(new Kup(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getInt(5), rs.getString(6), rs.getDate(7)==null? null: new Date(rs.getDate(7).getTime()), rs.getInt(8), i)); break;}
                         case 16:{kup_mecevi_16.add(new Kup(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getInt(5), rs.getString(6), rs.getDate(7)==null? null: new Date(rs.getDate(7).getTime()), rs.getInt(8), i)); break;}
                     }
                     }
                 }
             
              
        } catch (SQLException ex) {
            
        } finally {
            DB.getInstance().putConnection(c);
        }
     } 

     }

    //KUP napravi zreb
     public void kup_napravi_zreb(){
         long seed=System.nanoTime();
         Collections.shuffle(takmicari_int, new Random(seed));
         
        
         Connection c = DB.getInstance().getConnection();
         if (c == null) {
             return;

         }

         try {
             
                 
             int br = takmicari_int.size();
             for (int i = 0; i < br; i=i+2) {
                 Statement st = c.createStatement();
                 String upit = "insert into kup (tim1, tim2, takmicenje,runda) values ('"+takmicari_int.get(i)+"','"+takmicari_int.get(i+1)+"','"+trenutno_takmicenje_delegat+"','"+br/2+"');";
                 st.executeUpdate(upit);
             }
             
             
             br/=4;
             while(br!=1){
                 for(int i=0; i<br; i++){
                    Statement st = c.createStatement();
                    String upit = "insert into kup (takmicenje,runda) values ('"+trenutno_takmicenje_delegat+"','"+br+"');";
                    st.executeUpdate(upit);
                 }
                 br/=2;
             
             }
             Statement st1 = c.createStatement();
             String upit1 = "insert into kup (takmicenje,runda) values ('" + trenutno_takmicenje_delegat + "','" + 1 + "');";
             st1.executeUpdate(upit1);
             Statement st2 = c.createStatement();
             String upit2 = "insert into kup (takmicenje,runda) values ('" + trenutno_takmicenje_delegat + "','" + 1 + "');";
             st2.executeUpdate(upit2);

             prvo_logovanje_delegat=false;
             kup_prikazi_raspored();

         } catch (SQLException ex) {
            
        } finally {
            DB.getInstance().putConnection(c);
        }
         
         
         
     }
     
     
     
     //KUP prvo logovanje(provera)
     public String kup_prvo_logovanje(){
         
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return null;
            
        }
       
        try {
            Statement st=c.createStatement();
            String upit="SELECT * FROM kup where takmicenje='"+trenutno_takmicenje_delegat+"';";
            ResultSet rs=st.executeQuery(upit);
            if (!(rs.next())){
                prvo_logovanje_delegat=true;
                return null;
            }
            prvo_logovanje_delegat=false;
            return null;
            
        } catch (SQLException ex) {
            return null;
        } finally {
            DB.getInstance().putConnection(c);
        }
     
     
     }
     
     
     
     
     
     
     //GRUPE
     //Kraj grupne faze GRUPE
     public void kraj_grupne_faze(){
         
         List<Grupe2x6> Agrupa=new ArrayList<Grupe2x6>(grupaA_runda1);
         Agrupa.addAll(grupaA_runda2);
         Agrupa.addAll(grupaA_runda3);
         Agrupa.addAll(grupaA_runda4);
         Agrupa.addAll(grupaA_runda5);
         
         List<Grupe2x6> Bgrupa=new ArrayList<Grupe2x6>(grupaB_runda1);
         Bgrupa.addAll(grupaB_runda2);
         Bgrupa.addAll(grupaB_runda3);
         Bgrupa.addAll(grupaB_runda4);
         Bgrupa.addAll(grupaB_runda5);
         
         List<Pomocna_int_int> abodovi=new ArrayList<Pomocna_int_int>();
         List<Pomocna_int_int> bbodovi=new ArrayList<Pomocna_int_int>();
         for(Grupe2x6 gr:grupaA_runda1){
             abodovi.add(new Pomocna_int_int(gr.getTim1(), 0));
             abodovi.add(new Pomocna_int_int(gr.getTim2(), 0));
         }
         for(Grupe2x6 gr:grupaB_runda1){
             bbodovi.add(new Pomocna_int_int(gr.getTim1(), 0));
             bbodovi.add(new Pomocna_int_int(gr.getTim2(), 0));
         }
         for (Grupe2x6 gr:Agrupa){
             int t1,t2;
             if(gr.getPoeni_tim1()>gr.getPoeni_tim2()){
                 t1=2;
                 t2=1;
             }
             else {
                 t1=1;
                 t2=2;
             }
             for(Pomocna_int_int pom:abodovi){
                 if(pom.getTim()==gr.getTim1()){
                     pom.setPoeni(pom.getPoeni()+t1);
                 }
                  if(pom.getTim()==gr.getTim2()){
                     pom.setPoeni(pom.getPoeni()+t2);
                 }
             }
         }
         for (Grupe2x6 gr:Bgrupa){
             int t1,t2;
             if(gr.getPoeni_tim1()>gr.getPoeni_tim2()){
                 t1=2;
                 t2=1;
             }
             else {
                 t1=1;
                 t2=2;
             }
             for(Pomocna_int_int pom:bbodovi){
                 if(pom.getTim()==gr.getTim1()){
                     pom.setPoeni(pom.getPoeni()+t1);
                 }
                  if(pom.getTim()==gr.getTim2()){
                     pom.setPoeni(pom.getPoeni()+t2);
                 }
             }
         }
         Collections.sort(abodovi, (Pomocna_int_int b,Pomocna_int_int a)->Integer.compare(a.getPoeni(), b.getPoeni()));
         Collections.sort(bbodovi, (Pomocna_int_int b,Pomocna_int_int a)->Integer.compare(a.getPoeni(), b.getPoeni()));
         
         int i=0;
         for(Grupe2x6 gr:Q_grupe){
             
                gr.setTim1(abodovi.get(i).getTim()); 
                gr.setTim2(bbodovi.get(3-i).getTim()); 
                i++;
             
             
         }
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return;
            
        }
      
         try {
             for (Grupe2x6 gr : Q_grupe) {
                 Statement st = c.createStatement();
                 String upit = "update grupe2x6 set tim1='"+gr.getTim1()+"', tim2='"+gr.getTim2()+"' where utakmica_id='"+gr.getUtakmica_id()+"';";
                 st.execute(upit);

             } 
            
        } catch (SQLException ex) {
            
        } finally {
            DB.getInstance().putConnection(c);
        }
         
         
     }     

     
     
     //Zavrsetak takmicenja grupe + inkrement medalja GRUPE
     public String zavrsi_takmicenje_grupe(){
         Connection c = DB.getInstance().getConnection();
        if (c == null) {
            //potvrda nije uspela
            return null;
            
        }
        FacesContext context = FacesContext.getCurrentInstance();
        try {
            Statement stm1 = c.createStatement();
            String upitstm1 = "select zavrseno from takmicenja where takmicenje_id='" + trenutno_takmicenje_delegat + "';";
            ResultSet rsstm1 = stm1.executeQuery(upitstm1);
            rsstm1.next();
            if (rsstm1.getInt(1) != 0) {
                context.addMessage(null, new FacesMessage("Poruka:", "Takmicenje je vec zavrseno!!!"));
                zavrseno_takmicenje = true;
                return null;

            }
            
            
            int zlato, srebro, bronza;
            if(M_grupe.get(1).getPoeni_tim1()>M_grupe.get(1).getPoeni_tim2()){
                zlato=M_grupe.get(1).getTim1();
                srebro=M_grupe.get(1).getTim2();
            }
            else {
                zlato=M_grupe.get(1).getTim2();
                srebro=M_grupe.get(1).getTim1();
            }
            bronza=M_grupe.get(0).getPoeni_tim1()>M_grupe.get(0).getPoeni_tim2()? M_grupe.get(0).getTim1():M_grupe.get(0).getTim2();
            Statement st1=c.createStatement();
            Statement st2=c.createStatement();
            Statement st3=c.createStatement();
            String upit1="update zemlje set zlato=zlato+1 where zemlja_id='"+zlato+"';";
            String upit2="update zemlje set srebro=srebro+1 where zemlja_id='"+srebro+"';";
            String upit3="update zemlje set bronza=bronza+1 where zemlja_id='"+bronza+"';";
            st1.execute(upit1);
            st2.execute(upit2);
            st3.execute(upit3);
           
            Statement st=c.createStatement();
            String upit="update sportisti set medalja=medalja+1 where sport='"+trenutno_takmicenje_delegat_tak.getSport()+"' and pol='"+trenutno_takmicenje_delegat_tak.getPol()+"' and (zemlja='"+zlato+"' or zemlja='"+srebro+"' or zemlja='"+bronza+"');";
            st.execute(upit);
            trenutno_stanje_takmicenja[0]=true;
            Statement stm2=c.createStatement();
            String upitstm2="update takmicenja set zavrseno='1' where takmicenje_id='"+trenutno_takmicenje_delegat+"';";
            stm2.execute(upitstm2);
            zavrseno_takmicenje=true;
            return null;
            
        } catch (SQLException ex) {
            //nije uspelo
            return null;
        } finally {
            DB.getInstance().putConnection(c);
        }
         
         
     }
     
     //potvrda termina, lokacija visa faza
     public void potvrda_termina_lokacija_visa_faza(){
     
         FacesContext context = FacesContext.getCurrentInstance();
         
         if(!zakazane_grupe_delegat){
             context.addMessage(null, new FacesMessage("Poruka:",  "Prvo moraju biti zakazani termini utakmica po grupama!!!" ) );
             return;
         
         }
         
         List<Grupe2x6> pomocna=new ArrayList<Grupe2x6>(Q_grupe);
         pomocna.addAll(S_grupe);
         pomocna.addAll(M_grupe);
         
         
         for(Grupe2x6 gr:pomocna){
             if (gr.getTermin()==null){
                 context.addMessage(null, new FacesMessage("Poruka:",  "Morate izabrati termine svih utakmica!!!" ) );
                 return;
             }
             
         }
         
         
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return;
            
        }
       
        try {
            int i=0;
            for(Grupe2x6 gr:pomocna){
                for(int j=0; j<=i-1 ; j++)
                {
                    if(gr.getTermin().getTime()==pomocna.get(j).getTermin().getTime() && gr.getLokacija().equals(pomocna.get(j).getLokacija())){
                        context.addMessage(null, new FacesMessage("Poruka:",  "Morate izabrati drugi termin za mec "+nazivZemlje(gr.getTim1())+" - "+nazivZemlje(gr.getTim2())+" zbog zauzetosti lokacije!!!" ) );
                        return;
                    }
                }
                i++;
                Statement st=c.createStatement();
                String upit="select termin from grupe2x6 where lokacija='"+gr.getLokacija()+"';" ;
                ResultSet rs=st.executeQuery(upit);
                while (rs.next()) {                    
                    if (rs.getTime(1).getTime()==gr.getTermin().getTime()){
                    context.addMessage(null, new FacesMessage("Poruka:",  "Morate izabrati drugi termin za mec "+nazivZemlje(gr.getTim1())+" - "+nazivZemlje(gr.getTim2())+" zbog zauzetosti lokacije!!!" ) );
                    return;
                
                }
                }
                
            }
            for(Grupe2x6 gr:pomocna){
                Statement st=c.createStatement();
                String upit="update grupe2x6 set lokacija='"+gr.getLokacija()+"', termin='"+new java.sql.Date(gr.getTermin().getTime())+"' where utakmica_id='"+gr.getUtakmica_id()+"';";
                st.execute(upit);
            }
            zakazane_grupe_delegat_visa_faza=true;
                
        } catch (SQLException e) {
             e.printStackTrace(System.err);
                System.err.println("SQLState: " +
                    ((SQLException)e).getSQLState());

                System.err.println("Error Code: " +
                    ((SQLException)e).getErrorCode());

                System.err.println("Message: " + e.getMessage()); e.printStackTrace(System.err);
                System.err.println("SQLState: " +
                    ((SQLException)e).getSQLState());

                System.err.println("Error Code: " +
                    ((SQLException)e).getErrorCode());

                System.err.println("Message: " + e.getMessage());
        } finally {
            DB.getInstance().putConnection(c);
        }
     
     
     
     }
     
    
     //potvrda rezultata visa faza
     public void sacuvaj_rezultate_visa_faza(List<Grupe2x6> l1, int b1, int b2){
     
         FacesContext context = FacesContext.getCurrentInstance();
         for (Grupe2x6 gr:l1){
             if (gr.getPoeni_tim1()==gr.getPoeni_tim2()){
                 context.addMessage(null, new FacesMessage("Poruka:",  "Rezultat utakmice "+ nazivZemlje(gr.getTim1())+" - "+nazivZemlje(gr.getTim2())+" ne sme biti neresen!!!" ) );
                 return;
             }
             
         
         }
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            //PORUKA NIJE USPELO DODAVANJE
            return;
            
        }
       
        try {
            for(Grupe2x6 gr:l1){
                Statement st1=c.createStatement();
                String upit1="update grupe2x6 set poeni_tim1='"+gr.getPoeni_tim1()+"', poeni_tim2='"+gr.getPoeni_tim2()+"' where utakmica_id='"+gr.getUtakmica_id()+"';";
                st1.execute(upit1);
         
         }
         if(b1==6){
             Grupe2x6 ut1,ut2;
             ut1=Q_grupe.get(0);
             ut2=Q_grupe.get(1);
             S_grupe.get(0).setTim1(ut1.getPoeni_tim1()>ut1.getPoeni_tim2()? ut1.getTim1(): ut1.getTim2());
             S_grupe.get(0).setTim2(ut2.getPoeni_tim1()>ut2.getPoeni_tim2()? ut2.getTim1(): ut2.getTim2());   
         
             ut1=Q_grupe.get(2);
             ut2=Q_grupe.get(3);
             S_grupe.get(1).setTim1(ut1.getPoeni_tim1()>ut1.getPoeni_tim2()? ut1.getTim1(): ut1.getTim2());
             S_grupe.get(1).setTim2(ut2.getPoeni_tim1()>ut2.getPoeni_tim2()? ut2.getTim1(): ut2.getTim2());   
             
             Statement st1=c.createStatement();
             String upit1 = "update grupe2x6 set tim1='"+S_grupe.get(0).getTim1()+"', tim2='"+S_grupe.get(0).getTim2()+"' where utakmica_id='"+S_grupe.get(0).getUtakmica_id()+"';";
             st1.execute(upit1);
             Statement st2=c.createStatement();
             String upit2 = "update grupe2x6 set tim1='"+S_grupe.get(1).getTim1()+"', tim2='"+S_grupe.get(1).getTim2()+"' where utakmica_id='"+S_grupe.get(1).getUtakmica_id()+"';";
             st2.execute(upit2);
         } 
         if(b1==7){
             Grupe2x6 ut1,ut2;
             ut1=S_grupe.get(0);
             ut2=S_grupe.get(1);
             M_grupe.get(0).setTim1(ut1.getPoeni_tim1()<ut1.getPoeni_tim2()? ut1.getTim1(): ut1.getTim2());
             M_grupe.get(0).setTim2(ut2.getPoeni_tim1()<ut2.getPoeni_tim2()? ut2.getTim1(): ut2.getTim2());   
             
             M_grupe.get(1).setTim1(ut1.getPoeni_tim1()>ut1.getPoeni_tim2()? ut1.getTim1(): ut1.getTim2());
             M_grupe.get(1).setTim2(ut2.getPoeni_tim1()>ut2.getPoeni_tim2()? ut2.getTim1(): ut2.getTim2());   
             
             Statement st1=c.createStatement();
             String upit1 = "update grupe2x6 set tim1='"+M_grupe.get(0).getTim1()+"', tim2='"+M_grupe.get(0).getTim2()+"' where utakmica_id='"+M_grupe.get(0).getUtakmica_id()+"';";
             st1.execute(upit1);
             Statement st2=c.createStatement();
             String upit2 = "update grupe2x6 set tim1='"+M_grupe.get(1).getTim1()+"', tim2='"+M_grupe.get(1).getTim2()+"' where utakmica_id='"+M_grupe.get(1).getUtakmica_id()+"';";
             st2.execute(upit2);
         
         }
           trenutno_stanje_takmicenja[b1]=false;
           trenutno_stanje_takmicenja[b2]=true;
           
         } catch (SQLException ex) {
            //PORUKA NIJE USPELO
        } finally {
            DB.getInstance().putConnection(c);
        }
     
     
     }
     
    //trenutna faza unosa grupe
     public void trenutna_faza_grupe(){
        if(prvo_logovanje_delegat){
            zakazane_grupe_delegat=false;
            trenutno_stanje_takmicenja[1]=true;
            trenutno_stanje_takmicenja[0]=false; 
            zakazane_grupe_delegat_visa_faza=false;
            for(int i=2; i<10; i++){
                    trenutno_stanje_takmicenja[i]=false;
                }
                return;
        
        } 
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return;
            
        }
        
        try {
            Statement st=c.createStatement();
            String upit="SELECT COUNT(*) FROM `grupe2x6` WHERE termin IS null AND (runda=1 or runda=2 or runda=3 or runda=4 or runda=5) AND takmicenje='"+trenutno_takmicenje_delegat+"';";
            ResultSet rs=st.executeQuery(upit);
            rs.next();
            if (rs.getInt(1)!=0){
                zakazane_grupe_delegat=false;
                trenutno_stanje_takmicenja[1]=true;
                trenutno_stanje_takmicenja[0]=false;
                zakazane_grupe_delegat_visa_faza=false;
                for(int i=2; i<10; i++){
                    trenutno_stanje_takmicenja[i]=false;
                }
                return;
            }
            zakazane_grupe_delegat=true;
            
            Statement st2=c.createStatement();
            String upit2="SELECT COUNT(*) FROM `grupe2x6` WHERE termin IS null AND (runda='Q' or runda='S' or runda='M') AND takmicenje='"+trenutno_takmicenje_delegat+"';";
            ResultSet rs2=st.executeQuery(upit);
            rs2.next();
            zakazane_grupe_delegat_visa_faza = rs2.getInt(1) == 0;
            
            
            Statement st1=c.createStatement();
            String upit1="SELECT * FROM `grupe2x6` WHERE poeni_tim1 IS null AND poeni_tim2 IS null AND takmicenje='"+trenutno_takmicenje_delegat+"';";
            ResultSet rs1=st1.executeQuery(upit1);
            if (!rs1.next()){
                Statement stm1=c.createStatement();
                String upitstm1="select zavrseno from takmicenja where takmicenje_id='"+trenutno_takmicenje_delegat+"';";
                ResultSet rsstm1=stm1.executeQuery(upitstm1);
                rsstm1.next();
                if (rsstm1.getInt(1) != 0) {

                    zavrseno_takmicenje = true;
                    return;

                }
                
                zavrseno_takmicenje=true;
            }
            for(int i=0; i<10; i++){
                trenutno_stanje_takmicenja[i]=false;
            }
            switch (rs1.getString("runda")){
                case "1":{ trenutno_stanje_takmicenja[1]=true; break;}
                case "2":{ trenutno_stanje_takmicenja[2]=true; break;}
                case "3":{ trenutno_stanje_takmicenja[3]=true; break;}
                case "4":{ trenutno_stanje_takmicenja[4]=true; break;}
                case "5":{ trenutno_stanje_takmicenja[5]=true; break;}
                case "Q":{ trenutno_stanje_takmicenja[6]=true; break;}
                case "S":{ trenutno_stanje_takmicenja[7]=true; break;}
                case "M":{ trenutno_stanje_takmicenja[8]=true; break;}
            }
            
            
            
        } catch (SQLException ex) {
            
        } finally {
            DB.getInstance().putConnection(c);
        }
     
     
     }
     
     //potvrda rezultata grupa
     public void sacuvaj_rezultate_grupa(List<Grupe2x6> l1, List<Grupe2x6> l2, int b1, int b2){
         FacesContext context = FacesContext.getCurrentInstance();
         for (int i=0; i<3; i++){
             if (l1.get(i).getPoeni_tim1()==l1.get(i).getPoeni_tim2()){
                 context.addMessage(null, new FacesMessage("Poruka:",  "Rezultat utakmice "+ nazivZemlje(l1.get(i).getTim1())+" - "+nazivZemlje(l1.get(i).getTim2())+" ne sme biti neresen!!!" ) );
                 return;
             }
             if (l2.get(i).getPoeni_tim1()==l2.get(i).getPoeni_tim2()){
                 context.addMessage(null, new FacesMessage("Poruka:",  "Rezultat utakmice "+ nazivZemlje(l2.get(i).getTim1())+" - "+nazivZemlje(l2.get(i).getTim2())+" ne sme biti neresen!!!" ) );
                 return;
             }
         
         }
         Connection c = DB.getInstance().getConnection();
        if (c == null) {
            //PORUKA NIJE USPELO DODAVANJE
            return;
            
        }
       
        try {
            for(Grupe2x6 gr:l1){
                Statement st1=c.createStatement();
                String upit1="update grupe2x6 set poeni_tim1='"+gr.getPoeni_tim1()+"', poeni_tim2='"+gr.getPoeni_tim2()+"' where utakmica_id='"+gr.getUtakmica_id()+"';";
                st1.execute(upit1);
         
         }
            for(Grupe2x6 gr:l2){
                Statement st1=c.createStatement();
                String upit1="update grupe2x6 set poeni_tim1='"+gr.getPoeni_tim1()+"', poeni_tim2='"+gr.getPoeni_tim2()+"' where utakmica_id='"+gr.getUtakmica_id()+"';";
                st1.execute(upit1);
         
         }
            if (b1 == 5) {
                kraj_grupne_faze();
            }
            trenutno_stanje_takmicenja[b1] = false;
            trenutno_stanje_takmicenja[b2] = true;

            
            
            
        } catch (SQLException ex) {
            //PORUKA NIJE USPELO
        } finally {
            DB.getInstance().putConnection(c);
        }
         
     
     
     
     }
     
     //potvrda termina, lokacija grupe
     public void potvrda_termina_grupe_delegat(){
          FacesContext context = FacesContext.getCurrentInstance();
         for(int i=0; i<3; i++){
             if (grupaA_runda1.get(i).getTermin()==null){
                 context.addMessage(null, new FacesMessage("Poruka:",  "Morate izabrati termine svih utakmica!!!" ) );
                 return;
             }
             if (grupaB_runda1.get(i).getTermin()==null){
                 context.addMessage(null, new FacesMessage("Poruka:",  "Morate izabrati termine svih utakmica!!!" ) );
                 return;
             }
             if (grupaA_runda2.get(i).getTermin()==null){
                 context.addMessage(null, new FacesMessage("Poruka:",  "Morate izabrati termine svih utakmica!!!" ) );
                 return;
             }
             if (grupaB_runda2.get(i).getTermin()==null){
                 context.addMessage(null, new FacesMessage("Poruka:",  "Morate izabrati termine svih utakmica!!!" ) );
                 return;
             }
             if (grupaA_runda3.get(i).getTermin()==null){
                 context.addMessage(null, new FacesMessage("Poruka:",  "Morate izabrati termine svih utakmica!!!" ) );
                 return;
             }
             if (grupaB_runda3.get(i).getTermin()==null){
                 context.addMessage(null, new FacesMessage("Poruka:",  "Morate izabrati termine svih utakmica!!!" ) );
                 return;
             }
             if (grupaA_runda4.get(i).getTermin()==null){
                 context.addMessage(null, new FacesMessage("Poruka:",  "Morate izabrati termine svih utakmica!!!" ) );
                 return;
             }
             if (grupaB_runda4.get(i).getTermin()==null){
                 context.addMessage(null, new FacesMessage("Poruka:",  "Morate izabrati termine svih utakmica!!!" ) );
                 return;
             }
             if (grupaA_runda5.get(i).getTermin()==null){
                 context.addMessage(null, new FacesMessage("Poruka:",  "Morate izabrati termine svih utakmica!!!" ) );
                 return;
             }
             if (grupaB_runda5.get(i).getTermin()==null){
                 context.addMessage(null, new FacesMessage("Poruka:",  "Morate izabrati termine svih utakmica!!!" ) );
                 return;
             }
         }
         List<Grupe2x6> pomocna=new ArrayList<Grupe2x6>(grupaA_runda1);
         pomocna.addAll(grupaB_runda1);
         pomocna.addAll(grupaA_runda2);
         pomocna.addAll(grupaB_runda2);
         pomocna.addAll(grupaA_runda3);
         pomocna.addAll(grupaB_runda3);
         pomocna.addAll(grupaA_runda4);
         pomocna.addAll(grupaB_runda4);
         pomocna.addAll(grupaA_runda5);
         pomocna.addAll(grupaB_runda5);
         
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return;
            
        }
       
        try {
            int i=0;
            for(Grupe2x6 gr:pomocna){
                for(int j=0; j<=i-1 ; j++)
                {
                    if(gr.getTermin().getTime()==pomocna.get(j).getTermin().getTime() &&  gr.getLokacija().equals(pomocna.get(j).getLokacija())){
                        context.addMessage(null, new FacesMessage("Poruka:",  "Morate izabrati drugi termin za mec "+nazivZemlje(gr.getTim1())+" - "+nazivZemlje(gr.getTim2())+" zbog zauzetosti lokacije!!!" ) );
                        return;
                    }
                }
                i++;
                Statement st=c.createStatement();
                String upit="select termin from grupe2x6 where lokacija='"+gr.getLokacija()+"';" ;
                ResultSet rs=st.executeQuery(upit);
                while (rs.next()) {                    
                    if (rs.getTime(1).getTime()==gr.getTermin().getTime()){
                    context.addMessage(null, new FacesMessage("Poruka:",  "Morate izabrati drugi termin za mec "+nazivZemlje(gr.getTim1())+" - "+nazivZemlje(gr.getTim2())+" zbog zauzetosti lokacije!!!" ) );
                    return;
                
                }
                }
            }
            for(Grupe2x6 gr:pomocna){
                Statement st=c.createStatement();
                String upit="update grupe2x6 set lokacija='"+gr.getLokacija()+"', termin='"+new java.sql.Date(gr.getTermin().getTime())+"' where utakmica_id='"+gr.getUtakmica_id()+"';";
                st.execute(upit);
            }
            zakazane_grupe_delegat=true;
                
        } catch (SQLException e) {
             e.printStackTrace(System.err);
                System.err.println("SQLState: " +
                    ((SQLException)e).getSQLState());

                System.err.println("Error Code: " +
                    ((SQLException)e).getErrorCode());

                System.err.println("Message: " + e.getMessage()); e.printStackTrace(System.err);
                System.err.println("SQLState: " +
                    ((SQLException)e).getSQLState());

                System.err.println("Error Code: " +
                    ((SQLException)e).getErrorCode());

                System.err.println("Message: " + e.getMessage());
        } finally {
            DB.getInstance().putConnection(c);
        }
         
         
        
         
     
     
     }
     
     
     //PRIKAZI GRUPE DELEGAT
     public String prikazi_grupe(){
         
        if (!prvo_logovanje_delegat){ 
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            //poruka
            return null;
            
        }
       
        try {
        grupaA_runda1=new ArrayList<Grupe2x6>();
        grupaB_runda1=new ArrayList<Grupe2x6>();
        grupaA_runda2=new ArrayList<Grupe2x6>();
        grupaB_runda2=new ArrayList<Grupe2x6>();
        grupaA_runda3=new ArrayList<Grupe2x6>();
        grupaB_runda3=new ArrayList<Grupe2x6>();
        grupaA_runda4=new ArrayList<Grupe2x6>();
        grupaB_runda4=new ArrayList<Grupe2x6>();
        grupaA_runda5=new ArrayList<Grupe2x6>();
        grupaB_runda5=new ArrayList<Grupe2x6>();
        
        
        
            Statement st1=c.createStatement();
            Statement st2=c.createStatement();
            Statement st3=c.createStatement();
            Statement st4=c.createStatement();
            Statement st5=c.createStatement();
            
            
            String upit1="select * from grupe2x6 where runda=1 and takmicenje='"+trenutno_takmicenje_delegat+"';";
            String upit2="select * from grupe2x6 where runda=2 and takmicenje='"+trenutno_takmicenje_delegat+"';";
            String upit3="select * from grupe2x6 where runda=3 and takmicenje='"+trenutno_takmicenje_delegat+"';";
            String upit4="select * from grupe2x6 where runda=4 and takmicenje='"+trenutno_takmicenje_delegat+"';";
            String upit5="select * from grupe2x6 where runda=5 and takmicenje='"+trenutno_takmicenje_delegat+"';";
            
            
            ResultSet rs1=st1.executeQuery(upit1);
            ResultSet rs2=st2.executeQuery(upit2);
            ResultSet rs3=st3.executeQuery(upit3);
            ResultSet rs4=st4.executeQuery(upit4);
            ResultSet rs5=st5.executeQuery(upit5);
            
            while (rs1.next() && rs2.next() && rs3.next() && rs4.next() && rs5.next()) {
                if (rs1.getString("grupa").equals("A")) {
                    grupaA_runda1.add(new Grupe2x6(rs1.getInt(1), rs1.getString(2), rs1.getString(3), rs1.getInt(4), rs1.getInt(5), rs1.getInt(6), rs1.getInt(7), rs1.getInt(8),rs1.getDate(9)==null?null : new Date(rs1.getDate(9).getTime()),rs1.getString(10)));
                } else {
                    grupaB_runda1.add(new Grupe2x6(rs1.getInt(1), rs1.getString(2), rs1.getString(3), rs1.getInt(4), rs1.getInt(5), rs1.getInt(6), rs1.getInt(7), rs1.getInt(8),rs1.getDate(9)==null?null : new Date(rs1.getDate(9).getTime()),rs1.getString(10)));

                }
                if (rs2.getString("grupa").equals("A")) {
                    grupaA_runda2.add(new Grupe2x6(rs2.getInt(1), rs2.getString(2), rs2.getString(3), rs2.getInt(4), rs2.getInt(5), rs2.getInt(6), rs2.getInt(7), rs2.getInt(8),rs2.getDate(9)==null?null :  new Date(rs2.getDate(9).getTime()),rs2.getString(10)));
                } else {
                    grupaB_runda2.add(new Grupe2x6(rs2.getInt(1), rs2.getString(2), rs2.getString(3), rs2.getInt(4), rs2.getInt(5), rs2.getInt(6), rs2.getInt(7), rs2.getInt(8),rs2.getDate(9)==null?null :  new Date(rs2.getDate(9).getTime()),rs2.getString(10)));

                }
                if (rs3.getString("grupa").equals("A")) {
                    grupaA_runda3.add(new Grupe2x6(rs3.getInt(1), rs3.getString(2), rs3.getString(3), rs3.getInt(4), rs3.getInt(5), rs3.getInt(6), rs3.getInt(7), rs3.getInt(8),rs3.getDate(9)==null?null :  new Date(rs3.getDate(9).getTime()),rs3.getString(10)));
                } else {
                    grupaB_runda3.add(new Grupe2x6(rs3.getInt(1), rs3.getString(2), rs3.getString(3), rs3.getInt(4), rs3.getInt(5), rs3.getInt(6), rs3.getInt(7), rs3.getInt(8),rs3.getDate(9)==null?null :  new Date(rs3.getDate(9).getTime()),rs3.getString(10)));

                }
                if (rs4.getString("grupa").equals("A")) {
                    grupaA_runda4.add(new Grupe2x6(rs4.getInt(1), rs4.getString(2), rs4.getString(3), rs4.getInt(4), rs4.getInt(5), rs4.getInt(6), rs4.getInt(7), rs4.getInt(8),rs4.getDate(9)==null?null :  new Date(rs4.getDate(9).getTime()),rs4.getString(10)));
                } else {
                    grupaB_runda4.add(new Grupe2x6(rs4.getInt(1), rs4.getString(2), rs4.getString(3), rs4.getInt(4), rs4.getInt(5), rs4.getInt(6), rs4.getInt(7), rs4.getInt(8),rs4.getDate(9)==null?null :  new Date(rs4.getDate(9).getTime()),rs4.getString(10)));

                }
                if (rs5.getString("grupa").equals("A")) {
                    grupaA_runda5.add(new Grupe2x6(rs5.getInt(1), rs5.getString(2), rs5.getString(3), rs5.getInt(4), rs5.getInt(5), rs5.getInt(6), rs5.getInt(7), rs5.getInt(8),rs5.getDate(9)==null?null :  new Date(rs5.getDate(9).getTime()),rs5.getString(10)));
                } else {
                    grupaB_runda5.add(new Grupe2x6(rs5.getInt(1), rs5.getString(2), rs5.getString(3), rs5.getInt(4), rs5.getInt(5), rs5.getInt(6), rs5.getInt(7), rs5.getInt(8),rs5.getDate(9)==null?null :  new Date(rs5.getDate(9).getTime()),rs5.getString(10)));

                }
            }
            Q_grupe=new ArrayList<Grupe2x6>();
            S_grupe=new ArrayList<Grupe2x6>();
            M_grupe=new ArrayList<Grupe2x6>();
            
            Statement st6=c.createStatement();
            Statement st7=c.createStatement();
            Statement st8=c.createStatement();
            
            String upit6="select * from grupe2x6 where runda='Q' and takmicenje='"+trenutno_takmicenje_delegat+"';";
            String upit7="select * from grupe2x6 where runda='S' and takmicenje='"+trenutno_takmicenje_delegat+"';";
            String upit8="select * from grupe2x6 where runda='M' and takmicenje='"+trenutno_takmicenje_delegat+"';";
            
            ResultSet rs6=st6.executeQuery(upit6);
            ResultSet rs7=st7.executeQuery(upit7);
            ResultSet rs8=st8.executeQuery(upit8);
            
            while (rs6.next()) {                
                Q_grupe.add(new Grupe2x6(rs6.getInt(1), rs6.getString(2), rs6.getString(3), rs6.getInt(4), rs6.getInt(5), rs6.getInt(6), rs6.getInt(7), rs6.getInt(8),rs6.getDate(9)==null?null :  new Date(rs6.getDate(9).getTime()),rs6.getString(10)));
            }
            while (rs7.next()) {                
                S_grupe.add(new Grupe2x6(rs7.getInt(1), rs7.getString(2), rs7.getString(3), rs7.getInt(4), rs7.getInt(5), rs7.getInt(6), rs7.getInt(7), rs7.getInt(8),rs7.getDate(9)==null?null :  new Date(rs7.getDate(9).getTime()),rs7.getString(10)));
            }
            while (rs8.next()) {                
                M_grupe.add(new Grupe2x6(rs8.getInt(1), rs8.getString(2), rs8.getString(3), rs8.getInt(4), rs8.getInt(5), rs8.getInt(6), rs8.getInt(7), rs8.getInt(8),rs8.getDate(9)==null?null :  new Date(rs8.getDate(9).getTime()),rs8.getString(10)));
            }
            //Poruka
            return null;
           
            
            
            
        } catch (SQLException ex) {
            //poruka
            return null;
        } finally {
            DB.getInstance().putConnection(c);
        }
        }
        return null;
     
     }
     

//Delegat(Grupe) Raspodela po grupama
     public String rasporedi_po_grupama_delegat(){
     
         long seed=System.nanoTime();
         Collections.shuffle(takmicari_int, new Random(seed));
         
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            //ubaciti poruku (neuspesno rasporedjivanje)
            return null;
        }
        try {
         for(int i=1; i<6 ; i++){
             int p1 = 0,q1 = 0,p2 = 0,q2 = 0,p3 = 0,q3 = 0;
             switch (i){
                 case 1: {
                     p1 = 1;
                     q1 = 2;
                     p2 = 3;
                     q2 = 5;
                     p3 = 4;
                     q3 = 6;
                     break;
                 }
                 case 2: {
                     p1 = 3;
                     q1 = 1;
                     p2 = 6;
                     q2 = 2;
                     p3 = 5;
                     q3 = 4;
                     break;
                 }
                 case 3: {
                     p1 = 1;
                     q1 = 4;
                     p2 = 2;
                     q2 = 3;
                     p3 = 5;
                     q3 = 6;
                     break;
                 }
                 case 4: {
                     p1 = 5;
                     q1 = 1;
                     p2 = 4;
                     q2 = 2;
                     p3 = 6;
                     q3 = 3;
                     break;
                 }
                 case 5: {
                     p1 = 1;
                     q1 = 6;
                     p2 = 2;
                     q2 = 5;
                     p3 = 3;
                     q3 = 4;
                     break;
                 }

             }
            
            p1--;
            q1--;
            p2--;
            q2--;
            p3--;
            q3--;
        
       
        
            Statement st1=c.createStatement();
            Statement st2=c.createStatement();
            Statement st3=c.createStatement();
            Statement st4=c.createStatement();
            Statement st5=c.createStatement();
            Statement st6=c.createStatement();
            
            String upit1="insert into grupe2x6 (grupa,runda,tim1,tim2,takmicenje) values ('A','"+i+"','"+takmicari_int.get(p1)+"','"+takmicari_int.get(q1)+"','"+trenutno_takmicenje_delegat+"');";
            String upit2="insert into grupe2x6 (grupa,runda,tim1,tim2,takmicenje) values ('A','"+i+"','"+takmicari_int.get(p2)+"','"+takmicari_int.get(q2)+"','"+trenutno_takmicenje_delegat+"');";
            String upit3="insert into grupe2x6 (grupa,runda,tim1,tim2,takmicenje) values ('A','"+i+"','"+takmicari_int.get(p3)+"','"+takmicari_int.get(q3)+"','"+trenutno_takmicenje_delegat+"');";
            String upit4="insert into grupe2x6 (grupa,runda,tim1,tim2,takmicenje) values ('B','"+i+"','"+takmicari_int.get(p1+6)+"','"+takmicari_int.get(q1+6)+"','"+trenutno_takmicenje_delegat+"');";
            String upit5="insert into grupe2x6 (grupa,runda,tim1,tim2,takmicenje) values ('B','"+i+"','"+takmicari_int.get(p2+6)+"','"+takmicari_int.get(q2+6)+"','"+trenutno_takmicenje_delegat+"');";
            String upit6="insert into grupe2x6 (grupa,runda,tim1,tim2,takmicenje) values ('B','"+i+"','"+takmicari_int.get(p3+6)+"','"+takmicari_int.get(q3+6)+"','"+trenutno_takmicenje_delegat+"');";
            
            st1.executeUpdate(upit1);
            st2.executeUpdate(upit2);
            st3.executeUpdate(upit3);
            st4.executeUpdate(upit4);
            st5.executeUpdate(upit5);
            st6.executeUpdate(upit6);
       
         }  
         for (int i=1; i<5; i++){
             Statement st1=c.createStatement();
             String upit1="insert into grupe2x6 (runda,tim1,tim2,takmicenje) values ('Q','0','0','"+trenutno_takmicenje_delegat+"');";
             st1.executeUpdate(upit1);
         }
         for (int i=1; i<3; i++){
             Statement st1=c.createStatement();
             String upit1="insert into grupe2x6 (runda,tim1,tim2,takmicenje) values ('S','0','0','"+trenutno_takmicenje_delegat+"');";
             st1.executeUpdate(upit1);
             Statement st2=c.createStatement();
             String upit2="insert into grupe2x6 (runda,tim1,tim2,takmicenje) values ('M','0','0','"+trenutno_takmicenje_delegat+"');";
             st2.executeUpdate(upit2);
         }
         
         
         
         
         
         //PORUKA
         prvo_logovanje_delegat=false;
         prikazi_grupe();
         return null;
        
         } catch (SQLException e) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " +
                    ((SQLException)e).getSQLState());

                System.err.println("Error Code: " +
                    ((SQLException)e).getErrorCode());

                System.err.println("Message: " + e.getMessage()); e.printStackTrace(System.err);
                System.err.println("SQLState: " +
                    ((SQLException)e).getSQLState());

                System.err.println("Error Code: " +
                    ((SQLException)e).getErrorCode());

                System.err.println("Message: " + e.getMessage());
             //ubaciti poruku (neuspesno rasporedjivanje)
            return null;
        } finally {
            DB.getInstance().putConnection(c);
        }


     }
            
        
         
     
     
     
     
     //Delegat(Grupe) provera_prvo_logovanje
     public String prvo_logovanje_delegat_grupe(){
        
       
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return null;
            
        }
       
        try {
            Statement st=c.createStatement();
            String upit="SELECT * FROM grupe2x6 where takmicenje='"+trenutno_takmicenje_delegat+"';";
            ResultSet rs=st.executeQuery(upit);
            if (!(rs.next())){
                prvo_logovanje_delegat=true;
                return null;
            }
            prvo_logovanje_delegat=false;
            zakazane_grupe_delegat=false;
            return null;
            
        } catch (SQLException ex) {
            return null;
        } finally {
            DB.getInstance().putConnection(c);
        }
     
     
     
     }
     //Trka
     
     //Trka trenutna faza
     public void trka_trenutna_faza() {
     
        if (!prvo_logovanje_delegat) {

            FacesContext context = FacesContext.getCurrentInstance();
            Connection c = DB.getInstance().getConnection();
            if (c == null) {
                return;

            }
            try {

                Statement stm1 = c.createStatement();
                String upitstm1 = "select zavrseno from takmicenja where takmicenje_id='" + trenutno_takmicenje_delegat + "';";
                ResultSet rsstm1 = stm1.executeQuery(upitstm1);
                rsstm1.next();
                zavrseno_takmicenje = rsstm1.getInt(1) != 0;

            } catch (SQLException ex) {

            } finally {
                DB.getInstance().putConnection(c);
            }
        }
    }
     //Trka zavrsi takmicenje
     public void trka_zavrsi_takmicenje(){
         
         FacesContext context = FacesContext.getCurrentInstance();
         Connection c = DB.getInstance().getConnection();
         if (c == null) {
            return;
            
        }
        
         
        try {
            
            Statement stm1=c.createStatement();
            String upitstm1="select zavrseno from takmicenja where takmicenje_id='"+trenutno_takmicenje_delegat+"';";
            ResultSet rsstm1=stm1.executeQuery(upitstm1);
            rsstm1.next();
            if (rsstm1.getInt(1)!=0){
                context.addMessage(null, new FacesMessage("Poruka:",  "Takmicenje je vec zavrseno!!!" ) );
                zavrseno_takmicenje=true;
                return;
                
            } 
            upisi_u_bazu_delegat();
            
            Statement st2=c.createStatement();
            
            String upit2="SELECT ucesnik FROM trka WHERE rezultat<>'' AND takmicenje='"+trenutno_takmicenje_delegat+"' ORDER BY rezultat ";
            ResultSet rs2=st2.executeQuery(upit2);
            int i=0;
            int zlato=0, srebro=0, bronza=0;
            while(rs2.next()){
                if(i==0){zlato=rs2.getInt(1);}
                if(i==1){srebro=rs2.getInt(1);}
                if(i==2){bronza=rs2.getInt(1); break;}
                i++;
            }
            if (zlato !=0){
                Statement stzlato=c.createStatement();
                Statement stzlato1=c.createStatement();
                String upitzlato = "update zemlje set zlato=zlato+1 where zemlja_id='" + dohvati_zemlju_takmicara(zlato) + "';";
                String upitzlato1="update sportisti set medalja=medalja+1 where sportista_id='" + zlato + "';";
                stzlato.execute(upitzlato);
                stzlato1.execute(upitzlato1);
            }    
            if (srebro !=0){
                Statement stsrebro=c.createStatement();
                Statement stsrebro1=c.createStatement();
                String upitsrebro = "update zemlje set srebro=srebro+1 where zemlja_id='" + dohvati_zemlju_takmicara(srebro) + "';";
                String upitsrebro1="update sportisti set medalja=medalja+1 where sportista_id='" + srebro + "';";
                stsrebro.execute(upitsrebro);
                stsrebro1.execute(upitsrebro1);
            }     
             if (bronza !=0){
                Statement stbronza=c.createStatement();
                Statement stbronza1=c.createStatement();
                String upitbronza = "update zemlje set bronza=bronza+1 where zemlja_id='" + dohvati_zemlju_takmicara(bronza) + "';";
                String upitbronza1="update sportisti set medalja=medalja+1 where sportista_id='" + bronza + "';";
                stbronza.execute(upitbronza);
                stbronza1.execute(upitbronza1);
            }   
            
            zavrseno_takmicenje=true;
            Statement stm2=c.createStatement();
            String upitstm2="update takmicenja set zavrseno='1' where takmicenje_id='"+trenutno_takmicenje_delegat+"';";
            stm2.execute(upitstm2);
            
            } catch (SQLException ex) {
            
        } finally {
            DB.getInstance().putConnection(c);
        }
     
     
     
     
     }
     
     
     //Delegat(Trka) provera_prvo_logovanje
     public String prvo_logovanje_delegat_trka(){
        
       
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return null;
            
        }
       
        try {
            Statement st=c.createStatement();
            String upit="SELECT * FROM trka where takmicenje='"+trenutno_takmicenje_delegat+"';";
            ResultSet rs=st.executeQuery(upit);
            if (!(rs.next())){
                prvo_logovanje_delegat=true;
                return null;
            }
            prvo_logovanje_delegat=false;
            
            return null;
            
        } catch (SQLException ex) {
            return null;
        } finally {
            DB.getInstance().putConnection(c);
        }
     
     
     
     }
     
     //Delegat trka upis u bazu
     public String upisi_u_bazu_delegat(){
     
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,"Poruka", "Problem sa bazom, izmene nisu sacuvane."));
            return null;
            
        }
       
        try {
            for(Trka t:lista_trka_delegat){
            Statement st=c.createStatement();
            String upit="UPDATE trka SET rezultat='"+t.getRezultat()+"' WHERE trka_id='"+t.getTrka_id()+"';";
            st.execute(upit);
           
            }
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,"Poruka", "Izmene su uspesno sacuvane."));
            return null;
            
        } catch (SQLException ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,"Poruka", "Problem sa bazom, izmene nisu sacuvane."));
            return null;
        } finally {
            DB.getInstance().putConnection(c);
        }
        
     }
    // Delegat potvrda lokacije i vremena TRKA
     public String potvrda_trka_delegat(){
         
         if (delegat_datum.getTime()<trenutno_takmicenje_delegat_tak.getDatum_pocetka().getTime() || delegat_datum.getTime()>trenutno_takmicenje_delegat_tak.getDatum_kraja().getTime()){
             SimpleDateFormat sdf=new SimpleDateFormat("dd.MM.yyyy");
             FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,"Greska", "Takmicenje mora biti zakazano u terminu izmedju "+sdf.format(trenutno_takmicenje_delegat_tak.getDatum_pocetka())+" i "+sdf.format(trenutno_takmicenje_delegat_tak.getDatum_kraja())+"."));
             return null;
         }
         Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return null;
            
        }
       
        try {
            Statement st=c.createStatement();
            String upit="SELECT termin, lokacija FROM trka;";
            ResultSet rs=st.executeQuery(upit);
            while (rs.next()) {  
                if (rs.getString(2).equals(lokacija_trka_delegat) && ((new Date(rs.getTime(1).getTime()))==delegat_datum) ){
                    FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,"Upozorenje", "Izabrana lokacija je zauzeta u izabranom terminu."));
                    return null;
                
                }
            }
            
            for(int i:takmicari_int){
                Statement st1=c.createStatement();
                String upit1="insert into trka (takmicenje,ucesnik,termin,lokacija) values ('"+trenutno_takmicenje_delegat+"','"+i+"','"+new java.sql.Date(delegat_datum.getTime())+"','"+lokacija_trka_delegat+"');";
                st1.executeUpdate(upit1);
                
            }
            prvo_logovanje_delegat=false;
            trka_prikaz();
                   
            
            return null;
            
        } catch (SQLException ex) {
            return null;
        } finally {
            DB.getInstance().putConnection(c);
        }
        
     
     
     }
     
     //Trka prikaz
     public void trka_prikaz(){
     
        if (!prvo_logovanje_delegat) {
            Connection c = DB.getInstance().getConnection();
            if (c == null) {
                return;
            }
            try {
                Statement st1 = c.createStatement();
                lista_trka_delegat = new ArrayList<Trka>();
                String upit1 = "select * from trka where takmicenje='" + trenutno_takmicenje_delegat + "';";
                ResultSet rs1 = st1.executeQuery(upit1);
                while (rs1.next()) {
                    lista_trka_delegat.add(new Trka(rs1.getInt(1), rs1.getInt(2), rs1.getInt(3), new Date(rs1.getDate(4).getTime()), rs1.getString(5), rs1.getString(6)));
                }

            } catch (SQLException ex) {

            } finally {
                DB.getInstance().putConnection(c);
            }
        }
    }
     
    //PRIPREMA LOKACIJA I TAKMICARA (DELEGAT SVI) 
    public void delegat_priprema_tak_lok(){
    
    for(Takmicenje tak: delegat_takmicenja){
        if (tak.getTakmicenje_id()==trenutno_takmicenje_delegat) {
            trenutno_takmicenje_delegat_tak=tak;
            break;
        }
    }
    kup_ekipni=false;
    for(Disciplina dis:sport_extra){
        if (trenutno_takmicenje_delegat_tak.getDisciplina()==dis.getDisciplina_id() && dis.getVrsta().equals("ekipni")){
            kup_ekipni=true;
            break;
        }
    }
    
    String takmicari=trenutno_takmicenje_delegat_tak.getTakmicari();
    int poz=0;
     takmicari_int=new ArrayList<Integer>();
    int i=0;
    while(takmicari.indexOf(",", poz)!=-1){
        takmicari_int.add(Integer.parseInt(takmicari.substring(poz, takmicari.indexOf(",", poz))));
        poz=takmicari.indexOf(",", poz)+1;
    }
    String lokacije=trenutno_takmicenje_delegat_tak.getLokacije();
    poz=0;
    lokacije_delegat=new ArrayList<String>();
    while(lokacije.indexOf(",", poz)!=-1){
        lokacije_delegat.add(lokacije.substring(poz, lokacije.indexOf(",", poz)));
        poz=lokacije.indexOf(",", poz)+1;
    }
    

}


      //Delegat pokupi takmicenja
      public void pokupi_takmicenja(){
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return ;
            
        }
       
        try {
            Statement st=c.createStatement();
            String upit="SELECT * FROM takmicenja WHERE delegat='"+trenutni_korisnik.getKorisnik_id()+"';";
            ResultSet rs=st.executeQuery(upit);
            delegat_takmicenja=new ArrayList<Takmicenje>();
            while (rs.next()){
                delegat_takmicenja.add(new Takmicenje(rs.getInt(1),rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5), new Date(rs.getDate(6).getTime()),new Date(rs.getDate(7).getTime()), rs.getString(8), rs.getInt(9), rs.getString(10)));
            
            }
            
            
            
            
        } catch (SQLException ex) {
            
        } finally {
            DB.getInstance().putConnection(c);
        }
    
    }
    
    public  void nazad_org_tak(){
    
        izbor_igraca_rend_org_tak=false;
    
    }
    
    //Dali su promenjeni podaci ORGANIZATOR
    public void postavi_uslove_org_tak(){
    
        if (takmicari_takmicenje_izabrani){
            takmicari_takmicenje_izabrani=false;
        }
    
    }
    //Potvrda takmicara ORGANIZATOR
    public void potvrda_takmicara_org_tak(){
        
        int br_tak=izbor_ucesnika_tak_organizator.getTarget().size();
        
        if (format_org_tak.equals("grupe 2x6") && br_tak!=12)
        {   
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("Poruka:", "Broj takmicara  mora biti 12." ));
            return;
        }  
        if(format_org_tak.equals("kup") && !(br_tak==4 || br_tak==8 || br_tak==16 || br_tak==32)){
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("Poruka:", "Broj takmicara  mora biti ili 4 ili 8 ili 16 ili 32." ));
            return;
        
        }
        if(br_tak==0){
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("Poruka:", "Nije izabran ni jedan sportista." ));
            return;
        }
        takmicari_takmicenje="";
        for(Pom_lista_tak_zem pom: izbor_ucesnika_tak_organizator.getTarget()){
        
            takmicari_takmicenje+=pom.getId()+",";
        
        }
        
        izbor_igraca_rend_org_tak=false;
        takmicari_takmicenje_izabrani=true;
    }
    

//PICK LIST POPUNJAVANJE
    public void popuni_takmicare_org_tak(){
    
        if (organizator_tak_sport==0){
            
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("Poruka:", "Sport mora biti izabran" ));
            return ;
        }
        if (format_org_tak.equals("0")){
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("Poruka:", "Format mora biti izabran" ));
            return ;
        
        }
        if (organizator_tak_disciplina_izabrana==0 && organizator_tak_disciplina.size()>0){
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("Poruka:", "Disciplina mora biti izabrana" ));
            return ;
            
        }
        
        
        
        
        List<Pom_lista_tak_zem> source = new ArrayList<Pom_lista_tak_zem>();
        List<Pom_lista_tak_zem> target = new ArrayList<Pom_lista_tak_zem>();
        
        if (organizator_tak_disciplina_izabrana==0 && organizator_tak_disciplina.isEmpty()){
            for(Disciplina d: sport_extra){
                if (d.getSport()==organizator_tak_sport){
                    Connection c = DB.getInstance().getConnection();
                    if (c == null) {
                        return;

                    }

                    try {
                        Statement st = c.createStatement();
                        String upit = "SELECT zemlje.naziv,sportisti.zemlja, COUNT(*) AS broj FROM zemlje,sportisti WHERE zemlje.zemlja_id=sportisti.zemlja and sportisti.pol='" + pol_organizator_tak + "' and sportisti.sport='" + organizator_tak_sport + "'  GROUP BY sportisti.zemlja;";
                        ResultSet rs = st.executeQuery(upit);
                        while (rs.next()) {
                            if (rs.getInt(3) >= d.getMin_igraca()) {
                                source.add(new Pom_lista_tak_zem(rs.getInt(2), rs.getString(1)));
                            }
                        }
                        izbor_ucesnika_tak_organizator=new DualListModel<Pom_lista_tak_zem>(source, target);
                        if(source.isEmpty()){
                            FacesContext context = FacesContext.getCurrentInstance();
                            context.addMessage(null, new FacesMessage("Poruka:", "Za izabranu disciplinu nema prijavljenih takmicara!"));
                            return;

                        }
                        izbor_igraca_rend_org_tak=true;
                        return;

                    } catch (SQLException ex) {

                    } finally {
                        DB.getInstance().putConnection(c);
                    }
                }
            
            }
        }
        for(Disciplina d: sport_extra){
          
                if (d.getDisciplina_id() == organizator_tak_disciplina_izabrana)
                   if (d.getVrsta().equals("ekipni")) {

                    Connection c = DB.getInstance().getConnection();
                    if (c == null) {
                        return;

                    }

                    try {
                        Statement st = c.createStatement();
                        String upit = "SELECT zemlje.naziv,sportisti.zemlja, COUNT(*) AS broj FROM zemlje,sportisti WHERE zemlje.zemlja_id=sportisti.zemlja and sportisti.pol='" + pol_organizator_tak + "' and sportisti.disciplina='" + d.getDisciplina_id() + "'  GROUP BY sportisti.zemlja;";
                        ResultSet rs = st.executeQuery(upit);
                        while (rs.next()) {
                            if (rs.getInt(3) >= d.getMin_igraca()) {
                                source.add(new Pom_lista_tak_zem(rs.getInt(2), rs.getString(1)));
                            }
                        }

                        break;
                    } catch (SQLException ex) {

                    } finally {
                        DB.getInstance().putConnection(c);
                    }
                } else {

                    Connection c = DB.getInstance().getConnection();
                    if (c == null) {
                        return;
                    }
                    
                    try {
                        Statement st = c.createStatement();
                        String upit = "SELECT sportisti.sportista_id,sportisti.ime, sportisti.prezime FROM sportisti WHERE sportisti.pol='" + pol_organizator_tak + "' and sportisti.disciplina LIKE '," + d.getDisciplina_id() + ",' ORDER BY sportisti.ime ASC;";
                        ResultSet rs = st.executeQuery(upit);
                        while (rs.next()) {

                            source.add(new Pom_lista_tak_zem(rs.getInt(1), rs.getString(2) + " " + rs.getString(3)));

                        }

                    } catch (SQLException ex) {

                    } finally {
                        DB.getInstance().putConnection(c);
                    }

                }
        }
        
            if(source.isEmpty()){
                            FacesContext context = FacesContext.getCurrentInstance();
                            context.addMessage(null, new FacesMessage("Poruka:", "Za izabranu disciplinu nema prijavljenih takmicara!"));
                            return;

                        }
            izbor_ucesnika_tak_organizator = new DualListModel<Pom_lista_tak_zem>(source, target);
            izbor_igraca_rend_org_tak = true;
    
    }
    
    
    
    
    
    @PostConstruct
    public void init() {
        
        pokupi_delegate_organizator();
    }
    public void pokupi_delegate_organizator() {

        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return;

        }
        delegati_organizator_tak = new ArrayList<Korisnik>();
        try {
            Statement st = c.createStatement();
            String upit = "select * from korisnik where tip=1 and potvrdjen=1;";
            ResultSet rs = st.executeQuery(upit);

            while (rs.next()) {
                Statement st1 = c.createStatement();
                String upit1 = "SELECT COUNT(*) FROM takmicenja WHERE delegat='" + rs.getInt(1) + "' GROUP BY delegat;";
                ResultSet rs1 = st1.executeQuery(upit1);
                if (!rs1.next()) {
                    delegati_organizator_tak.add(new Korisnik(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(6), rs.getString(7), rs.getInt(8)));
                    continue;
                }
                if (rs1.getInt(1) < 3) {
                    delegati_organizator_tak.add(new Korisnik(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(6), rs.getString(7), rs.getInt(8)));

                }
            }

        } catch (SQLException ex) {

        } finally {
            DB.getInstance().putConnection(c);
        }

    }
    
    //DODAVANJE TAKMICENJA
    public String dodaj_organizator_tak(){
        
        if (organizator_tak_sport==0){
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("Poruka:", "Sport nije izabran!" ));
            return null;
        
        }
        if(datum_pocetka_organizator_tak==null){
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("Poruka:", "Datum pocetka nije postavljen!" ));
            return null;
        
        }
        if(datum_kraja_organizator_tak==null){
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("Poruka:", "Datum kraja takmicenja nije postavljen!" ));
            return null;
        
        }
        Date dat=new Date();
        if (dat.getTime()-datum_pocetka_organizator_tak.getTime()> 24*60*60*1000){
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("Poruka:", "Datum pocetka je nekorektan!" ));
            return null;
        
        }
        
        if(datum_kraja_organizator_tak.getTime()<datum_pocetka_organizator_tak.getTime()){
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("Poruka:", "Datum pocetka mora biti raniji od datuma kraja!" ));
            return null;
        
        }
        if(delegat_organizator_tak==-1){
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("Poruka:", "Delegat mora biti izabran!" ));
            return null;
        
        }
        if(!takmicari_takmicenje_izabrani){
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("Poruka:", "Takmicari nisu izabrani!" ));
            return null;
        
        }
        
        if(lokacija_org_tak.isEmpty()){
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("Dodavanje takmicenja nije uspelo:", "Lokacije moraju biti izabrane!" ));
            return null;
        
        }
        
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("Dodavanje takmicenja nije uspelo:", "Problem sa bazom podataka!" ));
            return null;
            
        }
        String lokacija="";
        for(String lok:lokacija_org_tak){
            lokacija+=lok+",";
        
        }
        java.sql.Date pocetak=new java.sql.Date(datum_pocetka_organizator_tak.getTime());
        java.sql.Date kraj=new java.sql.Date(datum_kraja_organizator_tak.getTime());
        
        int disciplina = 0;
        if(organizator_tak_disciplina_izabrana==0){
            for(Disciplina d:sport_extra){
                if(d.getSport()==organizator_tak_sport){
                    disciplina=d.getDisciplina_id();
                    break;
                }
            }
        
        }else{disciplina=organizator_tak_disciplina_izabrana;}
        try {
            Statement st=c.createStatement();
            String upit="insert into takmicenja (format, sport, disciplina, pol, datum_pocetka, datum_kraja, lokacije, delegat, takmicari) values ('"+format_org_tak+"','"+ organizator_tak_sport +"','"+disciplina+"','"+pol_organizator_tak+"','"+pocetak+"','"+kraj+"','"+lokacija+"','"+delegat_organizator_tak+"','"+takmicari_takmicenje+"');";
            st.executeUpdate(upit);
            
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("Poruka:", "Takmicenje je uspesno dodato!" ));
            pokupi_delegate_organizator();
            return null;
            
            
            
        } catch (SQLException ex) {
            
           
                ex.printStackTrace(System.err);
                System.err.println("SQLState: " +
                    ((SQLException)ex).getSQLState());

                System.err.println("Error Code: " +
                    ((SQLException)ex).getErrorCode());

                System.err.println("Message: " + ex.getMessage());

                
            
        
    
            
            
            
            
            
            
            
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("Dodavanje takmicenja nije uspelo:", "Problem sa bazom podataka!" ));
            return null;
        } finally {
            DB.getInstance().putConnection(c);
        }
        
    }
    
    
    public void organizator_tak_izdvoj_discipline(){
        
        organizator_tak_disciplina=new ArrayList<Disciplina>();
        if (0!=organizator_tak_sport) {
            for(Disciplina d: sport_extra){
                
                if(d.getSport()==organizator_tak_sport){
                    if (!(d.getNaziv()==null)){
                        organizator_tak_disciplina.add(d);
                    }
                }
            }
        } 
    
    }
    
    
    
    public String organizator_disciplina_dodaj(){
        FacesContext context = FacesContext.getCurrentInstance();
         
        
        
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            poruka_organizator="Problem sa bazom podataka, pokusajte kasnije!!!!";
            context.addMessage(null, new FacesMessage("Poruka",  poruka_organizator) );
            return null;
            
        }
       
        try {
            Statement st=c.createStatement();
            String upit1;
            if (organizator_disciplina_tip.equals("individualni")) {
                upit1 = "insert into sport_extra (sport_id, disciplina, vrsta) values ('" + organizator_disciplina_sport + "','" + organizator_disciplina_disciplina + "','" + organizator_disciplina_tip + "');";
            } else if (organizator_disciplina_disciplina.equals("")) {
                upit1 = "insert into sport_extra (sport_id, vrsta, min_igraca, max_igraca) values ('" + organizator_disciplina_sport + "','" + organizator_disciplina_tip + "','" + organizator_disciplina_min + "','" + organizator_disciplina_max + "');";

            } else {
                upit1 = "insert into sport_extra (sport_id, disciplina, vrsta, min_igraca, max_igraca) values ('" + organizator_disciplina_sport + "','" + organizator_disciplina_disciplina + "','" + organizator_disciplina_tip + "','" + organizator_disciplina_min + "','" + organizator_disciplina_max + "');";
            }

            st.executeUpdate(upit1);
            poruka_organizator="Nova disciplina je uspesno dodata!";
            context.addMessage(null, new FacesMessage("Poruka",  poruka_organizator) );
            return null;
            
            
        } catch (SQLException ex) {
             poruka_organizator="Problem sa bazom podataka, pokusajte kasnije!!!!";
             context.addMessage(null, new FacesMessage("Poruka",  poruka_organizator) );
             return null;
        } finally {
            DB.getInstance().putConnection(c);
        }
        
    }
    
    public String organizator_dodajsport(){
        
        FacesContext context = FacesContext.getCurrentInstance();
         
       
         Connection c = DB.getInstance().getConnection();
        if (c == null) {
            poruka_organizator="Problem sa bazom podataka, pokusajte kasnije!!!!";
            context.addMessage(null, new FacesMessage("Poruka",  poruka_organizator) );
            return null;
            
        }
       
        try {
            Statement st=c.createStatement();
            String upit="select * from sport where naziv='"+organizator_novisport+"';";
            ResultSet rs=st.executeQuery(upit);
            if (rs.next()){
                 poruka_organizator="Sport vec postoji u bazi podataka!!!!";
                 context.addMessage(null, new FacesMessage("Poruka",  poruka_organizator) );
                 return null;
            }
            Statement st1=c.createStatement();
            String upit1="insert into sport (naziv) values ('"+organizator_novisport+"');";
            st1.executeUpdate(upit1);
            poruka_organizator="Novi sport je uspesno dodat!";
            context.addMessage(null, new FacesMessage("Poruka",  poruka_organizator) );
            return null;
            
            
        } catch (SQLException ex) {
             poruka_organizator="Problem sa bazom podataka, pokusajte kasnije!!!!";
             context.addMessage(null, new FacesMessage("Poruka",  poruka_organizator) );
             return null;
        } finally {
            DB.getInstance().putConnection(c);
        }
    
    }
    
    public Kontroler() {
        pokupi_zemlje();
        pripremi_zemlje_za_prikaz();
        pokupi_sportove();
        pokupi_formate_lokacije();
       
    }
    
    public void pokupi_formate_lokacije(){
        
         Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return;
            
        }
        lokacije=new ArrayList<String>();
        formati=new ArrayList<Pom_lista_tak_zem>();
        rekordi=new ArrayList<Rekord>(); 
       
        try {
            Statement st1=c.createStatement();
            Statement st2=c.createStatement();
            Statement st3=c.createStatement();
            String upit1="select * from lokacije;";
            String upit2="select * from formati;";
            String upit3="select * from rekordi;";
            ResultSet rs1=st1.executeQuery(upit1);
            ResultSet rs2=st2.executeQuery(upit2);
            ResultSet rs3=st3.executeQuery(upit3);
            while (rs1.next()){lokacije.add(rs1.getString(1));}
            while (rs2.next()) {                
                formati.add(new Pom_lista_tak_zem(rs2.getInt(1), rs2.getString(2)));
                
            }
            while (rs3.next()) {                
                rekordi.add(new Rekord(rs3.getString(2), rs3.getString(3), rs3.getString(4), rs3.getString(5), rs3.getString(6), rs3.getString(7)));
            }
            
            
        } catch (SQLException ex) {
            
        } finally {
            DB.getInstance().putConnection(c);
        }
        
    
    }
    
    
    
 /*   public void init() {
        model = new DefaultMenuModel();
         
        //First submenu
        DefaultSubMenu firstSubmenu = new DefaultSubMenu("Dynamic Submenu");
         
        DefaultMenuItem item = new DefaultMenuItem("External");
        item.setUrl("http://www.primefaces.org");
        firstSubmenu.addElement(item);
         
        model.addElement(firstSubmenu);
         
        //Second submenu
        DefaultSubMenu secondSubmenu = new DefaultSubMenu("Dynamic Actions");
 
        item = new DefaultMenuItem("#{kontroler.trenutni_sport}");
        item.setIcon("ui-icon-disk");
        item.setCommand("#{menuView.save}");
        item.setUpdate("messages");
        secondSubmenu.addElement(item);
         
        item = new DefaultMenuItem("Delete");
        item.setIcon("ui-icon-close");
        item.setCommand("#{menuView.delete}");
        item.setAjax(false);
        secondSubmenu.addElement(item);
         
        item = new DefaultMenuItem("Redirect");
        item.setIcon("ui-icon-search");
        item.setCommand("#{menuView.redirect}");
        secondSubmenu.addElement(item);
 
        model.addElement(secondSubmenu);
    }
    
    */
    
    
    
    
    
    
    
    
    
    
    public String sportista_dodavanje(){
        FacesContext context = FacesContext.getCurrentInstance();
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            poruka_sportista="Dodavanje nije uspelo. Problem sa bazom podataka!!!";
            context.addMessage(null, new FacesMessage("Poruka",  poruka_sportista) );
            return null;

        }
        
        try {
            Statement st = c.createStatement();
            String upit = "select * from sport_extra where extra_id='" + sportista_izabrane_discipline[0] + "';";
            ResultSet rs = st.executeQuery(upit);
            rs.next();
            boolean ekipni=false;
            if (rs.getString("vrsta").equals("ekipni")) {
                ekipni=true;
            }
            int max,min;
            if (ekipni)
            {   max=rs.getInt("max_igraca");
                min=rs.getInt("min_igraca");
                Statement st1 = c.createStatement();
                String upit1 = "select count(*) from sportisti where disciplina like'%," + sportista_izabrane_discipline[0] + ",%' and zemlja='"+trenutni_korisnik.getDrzava()+"' and pol='"+sportista_pol+"';";
                ResultSet rs1 = st1.executeQuery(upit1);
                rs1.next();
          
                if (rs1.getInt(1)==max){
                
                    poruka_sportista="Za izabrani sport je vec prijavljen maksimalan broj igraca!!!";
                    context.addMessage(null, new FacesMessage("Poruka",  poruka_sportista) );
                    return null;
                }
                Statement st2 = c.createStatement();
                
                String upit2 = "INSERT INTO sportisti (ime, prezime, zemlja, sport, disciplina, medalja, pol) VALUES ('"+sportista_ime+"','"+sportista_prezime+"','"+trenutni_korisnik.getDrzava()+"','"+sportista_sport+"' , ',"+sportista_izabrane_discipline[0]+",',0,'"+ sportista_pol +"');";
                st2.execute(upit2);
                if (rs1.getInt(1)+1<min){
                    poruka_sportista="Igrac je prijavljen, za dati sport potrebno je prijaviti jos minimalno "+ (min-rs1.getInt(1)-1)+" igraca, pre pocetka takmicenja!!!";
                    context.addMessage(null, new FacesMessage("Poruka",  poruka_sportista) );
                    
                    return null;
                }
                poruka_sportista="Sportista je uspesno doadat!!!";
                context.addMessage(null, new FacesMessage("Poruka",  poruka_sportista) );
                return null;
            }
            String disciplina = ",";
            for (int i : sportista_izabrane_discipline) {
                disciplina += i + ",";
            }
            Statement st2 = c.createStatement();
            String upit2 = "INSERT INTO sportisti (ime, prezime, zemlja, sport, disciplina, medalja, pol) VALUES ('" + sportista_ime + "','" + sportista_prezime + "','" + trenutni_korisnik.getDrzava() + "','" + sportista_sport + "','" + disciplina + "',0,'" + sportista_pol + "');";
            st2.execute(upit2);
            poruka_sportista = "Sportista je uspesno doadat!!!";
            context.addMessage(null, new FacesMessage("Poruka",  poruka_sportista) );
            
            return null;

        } catch (SQLException ex) {
            poruka_sportista = "Dodavanje nije uspelo. Problem sa bazom podataka!!!";
            context.addMessage(null, new FacesMessage("Poruka",  poruka_sportista) );
            return null;
        } finally {
            DB.getInstance().putConnection(c);
        }


       }
    
    
    public void sportista_popunjavanje_disciplina(){
    
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return;
            
        }
        sportista_render_disc=false;
        sportista_disciplina_za_izbor=new ArrayList<Disciplina>();
        try {
            Statement st=c.createStatement();
            String upit="select * from sport_extra where sport_id='"+sportista_sport+"';";
            ResultSet rs=st.executeQuery(upit);
            while (rs.next()){
                if (nazivDiscipline(rs.getInt(1)).equals(""))    
                    sportista_izabrane_discipline[0]=rs.getInt(1);
                else{
                    sportista_render_disc=true;
                    sportista_disciplina_za_izbor.add(new Disciplina(rs.getInt(1), rs.getInt(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getInt(6)));
                }
            }
            
            
            
        } catch (SQLException ex) {
            
        } finally {
            DB.getInstance().putConnection(c);
        }
        
    }
    
    
    
    
    
    

    
    
    public String pretraga_sportista(){
        
        
        String uslov_zemlja="",uslov_sport="",uslov_disciplina="",uslov_medalja="",uslov_pol="";
        if (!(zemlja_pretraga==-1)){
            uslov_zemlja="and zemlja='"+zemlja_pretraga+"' ";
        }
        if (!(sport_pretraga==-1)){
            uslov_sport=" and sport='"+sport_pretraga+"' ";
        }
        if (!(disciplina_pretraga==-1)){
            uslov_disciplina=" and disciplina like +'%,"+disciplina_pretraga+",%' ";
        }
        if(check_pretraga){
            uslov_medalja=" and medalja>0";
        }
        if (pol_pretraga!=null){
        if (pol_pretraga.equals("M")) {
            uslov_pol = " and pol='M' ";
        } else if (pol_pretraga.equals("Z")) {
            uslov_pol = " and pol='Z' ";

        }
        }
        int pozicij_razmak=ime_prezime_pretraga.indexOf(" "); 
        String ime,prezime;
        if(pozicij_razmak==-1){
            ime=ime_prezime_pretraga;
            prezime="";
        }
        else    {    
                ime=ime_prezime_pretraga.substring(0, pozicij_razmak-1);
                prezime=ime_prezime_pretraga.substring(pozicij_razmak+1);
            }
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            poruka_pretraga="Pretraga nije uspela, problem sa bazom podataka!!!";
            return null;

        }
        sportisti_pretraga=new ArrayList<Sportista>();
        try {
            Statement st = c.createStatement();
            String upit="SELECT * FROM sportisti WHERE CONCAT ( ime, ' ', prezime )  like '%"+ime_prezime_pretraga+"%'  "+uslov_zemlja+uslov_sport+uslov_disciplina+uslov_medalja+uslov_pol+";";
            ResultSet rs=st.executeQuery(upit);
            while (rs.next()){
                sportisti_pretraga.add(new Sportista(rs.getInt(1), rs.getString(2), rs.getString(3)));
            
            }
            return null;
        } catch (SQLException ex) {
            poruka_pretraga = "Pretraga nije uspela, problem sa bazom podataka!!!";
            return null;

        } finally {
            DB.getInstance().putConnection(c);
        }
    
    }    
   
    
    public void pripremi_zemlje_za_prikaz(){
        
        
        Connection c = DB.getInstance().getConnection();
        if (c == null) {

            return;

        }
        try {
            Statement st = c.createStatement();
            String upit = "SELECT zemlja,count(*) as broj FROM sportisti GROUP BY zemlja;";
            ResultSet rs = st.executeQuery(upit);
            while (rs.next()){
                int i=0;
                while (zemlje.get(i).getZemlja_id()!=rs.getInt(1)){i++;}
                zemlje.get(i).setBroj_takmicara(rs.getInt(2));
            
            }
            Collections.sort(zemlje, (Zemlja a, Zemlja b) -> a.getNaziv().compareTo(b.getNaziv()));
            brojac=new ArrayList<>(zemlje);
            Collections.sort(brojac, (Zemlja b, Zemlja a) -> Integer.compare(a.getZlato() + a.getSrebro() + a.getBronza(), b.getZlato() + b.getSrebro() + b.getBronza()));
            
        } catch (SQLException ex) {

        } finally {
            DB.getInstance().putConnection(c);
        }
    
    }    
    public void pokupi_sportove(){
      Connection c = DB.getInstance().getConnection();
        if (c == null) {

            return;

        }
        try {
            Statement st = c.createStatement();
            Statement st1=c.createStatement();
            String upit = "SELECT * from sport_extra;";
            String upit1="SELECT * FROM sport;";
            ResultSet rs = st.executeQuery(upit1);
            ResultSet rs1 = st1.executeQuery(upit);
            discipline=new ArrayList<Disciplina>();
            sport_extra=new ArrayList<Disciplina>();
            sportovi=new ArrayList<Sport>();
            while (rs.next()){
                
                sportovi.add(new Sport(rs.getInt(1), rs.getString(2)));
            
            }
            
            while (rs1.next()){
                sport_extra.add(new Disciplina(rs1.getInt(1), rs1.getInt(2), rs1.getString(3), rs1.getString(4), rs1.getInt(5), rs1.getInt(6)));
                if (rs1.getString(3)!=null)
                discipline.add(new Disciplina(rs1.getInt(1), rs1.getInt(2), rs1.getString(3), rs1.getString(4), rs1.getInt(5), rs1.getInt(6)));
            
            }
        } catch (SQLException ex) {

        } finally {
            DB.getInstance().putConnection(c);
        }
    
        
    
    
    }
    

    public boolean provera_lozinke(String lozinka) {

        int l = lozinka.length();
        if (!(l <= 12 && l > 8)) {
            return false;
        }

        char c1 = lozinka.charAt(0);
        if (!((c1 >= 'a' && c1 <= 'z') || (c1 >= 'A' && c1 <= 'Z'))) {

            return false;
        }
        int veliko, malo, broj, spec;
        veliko = malo = broj = spec = 0;
        for (int i = 0; i < l; i++) {
            char c = lozinka.charAt(i);
            String provera = "" + c + c + c + c;
            if (lozinka.contains(provera)) {
                return false;

            }
            if (c >= 'a' && c <= 'z') {
                malo++;
            } else if (c >= 'A' && c <= 'Z') {
                veliko++;
            } else if (c >= '0' && c <= '9') {
                broj++;
            } else {
                spec++;
            }

        }
        return veliko >= 1 && malo >= 3 && broj >= 2 && spec >= 2;

    }

    public void pokupi_zemlje() {

        Connection c = DB.getInstance().getConnection();
        if (c == null) {

            return;

        }
        zemlje = new ArrayList<Zemlja>();
        try {
            Statement st = c.createStatement();
            String upit = "select * from zemlje ;";
            ResultSet rs = st.executeQuery(upit);
            while (rs.next()) {
                zemlje.add(new Zemlja(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getInt(5)));

            }

        } catch (SQLException ex) {

        } finally {
            DB.getInstance().putConnection(c);
        }

    }

    public String LogIn() {
        
        FacesContext context = FacesContext.getCurrentInstance();
        poruka_logovanje = "";
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            poruka_logovanje = "Problem sa bazom podataka! Pokusajte ponovo!";
            context.addMessage(null, new FacesMessage("Poruka",  poruka_logovanje) );
            return null;

        }
        try {
            Statement st = c.createStatement();
            String upit = "select * from korisnik where korisnickoime='" + korisnik + "' and potvrdjen=1;";
            ResultSet rs = st.executeQuery(upit);
            if (rs.next()) {
                if (rs.getString(3).equals(lozinka)) {
                    
                    if (rs.getInt("tip") == 0) {
                        trenutni_korisnik = new Korisnik(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(6), rs.getString(7), rs.getInt(8));
                        return "organizator";
                    }
                    
                    trenutni_korisnik = new Korisnik(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(6), rs.getString(7), rs.getInt(8));
             
                    if (trenutni_korisnik.getTip() == 1) {
                        pokupi_takmicenja();
                        return "delegat";
                    } else {
                        prikaz_delegacije_sportovi();
                        return "vodja_nac_del";
                    }
                } else {
                    poruka_logovanje = "Pogresna lozinka!!!!!!";
                    context.addMessage(null, new FacesMessage("Poruka",  poruka_logovanje) );
                    return null;

                }
            } else {
                korisnik = "";
                poruka_logovanje = "Ne postoji korisnik sa datim korisnickim imenom!!!!!!!";
                context.addMessage(null, new FacesMessage("Poruka",  poruka_logovanje) );
                return null;
            }

        } catch (SQLException ex) {
            poruka_logovanje = "Problem sa bazom podataka! Pokusajte ponovo!";
            context.addMessage(null, new FacesMessage("Poruka",  poruka_logovanje) );
            return null;

        } finally {
            DB.getInstance().putConnection(c);
        }

    }
    public String nazivSport(int  sp){
    
        for(Sport s: sportovi){
            if (s.getSport_id()==sp)
            {
                return s.getNaziv();
            }
        }
        return  "";
    }
    
    public String nazivDiscipline(int dis){
         for(Disciplina d: sport_extra){
            if (d.getDisciplina_id()==dis)
            {
               if(d.getNaziv()==null){return "";}
               else {return d.getNaziv();}
            }
        }
        return  "";
    
    
    }
     public String LogOut() {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) context.getExternalContext().getSession(false);
        session.invalidate();
       
        return "pocetna";
    }

    
    
    public String nazivZemlje(int zem){
        if (zem==0){
            return "?????";
        } 
        for(Zemlja z: zemlje){
            if (z.getZemlja_id()==zem)
            {
               return z.getNaziv();
            }
        }
        return  "";
    
    
    }
    
    public String imeSportiste(int id){
    
        if (id==0){
            return "???";
            
        }
        
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return null;
            
        }
       
        try {
            Statement st=c.createStatement();
            String upit="select ime, prezime from sportisti where sportista_id='"+id+"';";
            ResultSet rs=st.executeQuery(upit);
            rs.next();
            return rs.getString(1)+" "+rs.getString(2);
            
            
            
        } catch (SQLException ex) {
            return null;
        } finally {
            DB.getInstance().putConnection(c);
        }
    
    }
    
    public int dohvati_zemlju_takmicara(int tak){
        
        Connection c = DB.getInstance().getConnection();
        if (c == null) {
            return 0;
            
        }
       
        try {
            Statement st=c.createStatement();
            String upit="select zemlja from sportisti where sportista_id='"+tak+"';";
            ResultSet rs=st.executeQuery(upit);
            rs.next();
            return rs.getInt(1);
            
            
            
        } catch (SQLException ex) {
            return 0;
        } finally {
            DB.getInstance().putConnection(c);
        }
    
    
    }
    

    public String getKorisnik() {
        return korisnik;
    }

    public String getLozinka() {
        return lozinka;
    }

    public void setKorisnik(String korisnik) {
        this.korisnik = korisnik;
    }

    public void setLozinka(String lozinka) {
        this.lozinka = lozinka;
    }

    public String getPoruka_logovanje() {
        return poruka_logovanje;
    }

    public void setPoruka_logovanje(String poruka_logovanje) {
        this.poruka_logovanje = poruka_logovanje;
    }

    public Korisnik getTrenutni_korisnik() {
        return trenutni_korisnik;
    }

    public void setTrenutni_korisnik(Korisnik trenutni_korisnik) {
        this.trenutni_korisnik = trenutni_korisnik;
    }

    public List<Zemlja> getZemlje() {
        return zemlje;
    }

    public void setZemlje(List<Zemlja> zemlje) {
        this.zemlje = zemlje;
    }

   

    public List<Zemlja> getBrojac() {
        return brojac;
    }

    public void setBrojac(List<Zemlja> brojac) {
        this.brojac = brojac;
    }

    public List<Sport> getSportovi() {
        return sportovi;
    }

    public List<Disciplina> getDiscipline() {
        return discipline;
    }

    public void setSportovi(List<Sport> sportovi) {
        this.sportovi = sportovi;
    }

    public void setDiscipline(List<Disciplina> discipline) {
        this.discipline = discipline;
    }

    public List<Sportista> getSportisti_pretraga() {
        return sportisti_pretraga;
    }

    public void setSportisti_pretraga(List<Sportista> sportisti_pretraga) {
        this.sportisti_pretraga = sportisti_pretraga;
    }

    public String getIme_prezime_pretraga() {
        return ime_prezime_pretraga;
    }

    public String getPol_pretraga() {
        return pol_pretraga;
    }

    public int getZemlja_pretraga() {
        return zemlja_pretraga;
    }

    public int getSport_pretraga() {
        return sport_pretraga;
    }

    public int getDisciplina_pretraga() {
        return disciplina_pretraga;
    }

    public boolean isCheck_pretraga() {
        return check_pretraga;
    }

    public void setIme_prezime_pretraga(String ime_prezime_pretraga) {
        this.ime_prezime_pretraga = ime_prezime_pretraga;
    }

    public void setPol_pretraga(String pol_pretraga) {
        this.pol_pretraga = pol_pretraga;
    }

    public void setZemlja_pretraga(int zemlja_pretraga) {
        this.zemlja_pretraga = zemlja_pretraga;
    }

    public void setSport_pretraga(int sport_pretraga) {
        this.sport_pretraga = sport_pretraga;
    }

    public void setDisciplina_pretraga(int disciplina_pretraga) {
        this.disciplina_pretraga = disciplina_pretraga;
    }

    public void setCheck_pretraga(boolean check_pretraga) {
        this.check_pretraga = check_pretraga;
    }

    public String getPoruka_pretraga() {
        return poruka_pretraga;
    }

    public String getSportista_ime() {
        return sportista_ime;
    }

    public String getSportista_prezime() {
        return sportista_prezime;
    }

    public String getPoruka_sportista() {
        return poruka_sportista;
    }

    public int getSportista_sport() {
        return sportista_sport;
    }

    public boolean isSportista_render_disc() {
        return sportista_render_disc;
    }

    public List<Disciplina> getSportista_disciplina_za_izbor() {
        return sportista_disciplina_za_izbor;
    }

    public void setPoruka_pretraga(String poruka_pretraga) {
        this.poruka_pretraga = poruka_pretraga;
    }

    public void setSportista_ime(String sportista_ime) {
        this.sportista_ime = sportista_ime;
    }

    public void setSportista_prezime(String sportista_prezime) {
        this.sportista_prezime = sportista_prezime;
    }

    public void setPoruka_sportista(String poruka_sportista) {
        this.poruka_sportista = poruka_sportista;
    }

    public void setSportista_sport(int sportista_sport) {
        this.sportista_sport = sportista_sport;
    }

    public void setSportista_render_disc(boolean sportista_render_disc) {
        this.sportista_render_disc = sportista_render_disc;
    }

    public void setSportista_disciplina_za_izbor(List<Disciplina> sportista_disciplina_za_izbor) {
        this.sportista_disciplina_za_izbor = sportista_disciplina_za_izbor;
    }

    public int[] getSportista_izabrane_discipline() {
        return sportista_izabrane_discipline;
    }

    public void setSportista_izabrane_discipline(int[] sportista_izabrane_discipline) {
        this.sportista_izabrane_discipline = sportista_izabrane_discipline;
    }

    public String getSportista_pol() {
        return sportista_pol;
    }

    public void setSportista_pol(String sportista_pol) {
        this.sportista_pol = sportista_pol;
    }

    public String getOrganizator_novisport() {
        return organizator_novisport;
    }

    public void setOrganizator_novisport(String organizator_novisport) {
        this.organizator_novisport = organizator_novisport;
    }

    public String getPoruka_organizator() {
        return poruka_organizator;
    }

    public void setPoruka_organizator(String poruka_organizator) {
        this.poruka_organizator = poruka_organizator;
    }

    public String getOrganizator_disciplina_sport() {
        return organizator_disciplina_sport;
    }

    public void setOrganizator_disciplina_sport(String organizator_disciplina_sport) {
        this.organizator_disciplina_sport = organizator_disciplina_sport;
    }

    public String getOrganizator_disciplina_disciplina() {
        return organizator_disciplina_disciplina;
    }

    public void setOrganizator_disciplina_disciplina(String organizator_disciplina_disciplina) {
        this.organizator_disciplina_disciplina = organizator_disciplina_disciplina;
    }

    public String getOrganizator_disciplina_tip() {
        return organizator_disciplina_tip;
    }

    public void setOrganizator_disciplina_tip(String organizator_disciplina_tip) {
        this.organizator_disciplina_tip = organizator_disciplina_tip;
    }

    public String getOrganizator_disciplina_max() {
        return organizator_disciplina_max;
    }

    public void setOrganizator_disciplina_max(String organizator_disciplina_max) {
        this.organizator_disciplina_max = organizator_disciplina_max;
    }

    public String getOrganizator_disciplina_min() {
        return organizator_disciplina_min;
    }

    public void setOrganizator_disciplina_min(String organizator_disciplina_min) {
        this.organizator_disciplina_min = organizator_disciplina_min;
    }

    public List<Disciplina> getSport_extra() {
        return sport_extra;
    }

    public void setSport_extra(List<Disciplina> sport_extra) {
        this.sport_extra = sport_extra;
    }

    public List<Disciplina> getOrganizator_tak_disciplina() {
        return organizator_tak_disciplina;
    }

    public void setOrganizator_tak_disciplina(List<Disciplina> organizator_tak_disciplina) {
        this.organizator_tak_disciplina = organizator_tak_disciplina;
    }

    public int getOrganizator_tak_disciplina_izabrana() {
        return organizator_tak_disciplina_izabrana;
    }

    public void setOrganizator_tak_disciplina_izabrana(int organizator_tak_disciplina_izabrana) {
        this.organizator_tak_disciplina_izabrana = organizator_tak_disciplina_izabrana;
    }

    public int getOrganizator_tak_sport() {
        return organizator_tak_sport;
    }

    public void setOrganizator_tak_sport(int organizator_tak_sport) {
        this.organizator_tak_sport = organizator_tak_sport;
    }

    public Date getDatum_pocetka_organizator_tak() {
        return datum_pocetka_organizator_tak;
    }

    public void setDatum_pocetka_organizator_tak(Date datum_pocetka_organizator_tak) {
        this.datum_pocetka_organizator_tak = datum_pocetka_organizator_tak;
    }

    

    public String getPol_organizator_tak() {
        return pol_organizator_tak;
    }

    public void setPol_organizator_tak(String pol_organizator_tak) {
        this.pol_organizator_tak = pol_organizator_tak;
    }

    public Date getDatum_kraja_organizator_tak() {
        return datum_kraja_organizator_tak;
    }

    public void setDatum_kraja_organizator_tak(Date datum_kraja_organizator_tak) {
        this.datum_kraja_organizator_tak = datum_kraja_organizator_tak;
    }

    public DualListModel<Pom_lista_tak_zem> getIzbor_ucesnika_tak_organizator() {
        return izbor_ucesnika_tak_organizator;
    }

    public void setIzbor_ucesnika_tak_organizator(DualListModel<Pom_lista_tak_zem> izbor_ucesnika_tak_organizator) {
        this.izbor_ucesnika_tak_organizator = izbor_ucesnika_tak_organizator;
    }

    public List<String> getLokacije() {
        return lokacije;
    }

    public void setLokacije(List<String> lokacije) {
        this.lokacije = lokacije;
    }

    public List<Pom_lista_tak_zem> getFormati() {
        return formati;
    }

    public void setFormati(List<Pom_lista_tak_zem> formati) {
        this.formati = formati;
    }

    public String getFormat_org_tak() {
        return format_org_tak;
    }

    public void setFormat_org_tak(String format_org_tak) {
        this.format_org_tak = format_org_tak;
    }

    public List<String> getLokacija_org_tak() {
        return lokacija_org_tak;
    }

    public void setLokacija_org_tak(List<String> lokacija_org_tak) {
        this.lokacija_org_tak = lokacija_org_tak;
    }

    public int getDelegat_organizator_tak() {
        return delegat_organizator_tak;
    }

    public void setDelegat_organizator_tak(int delegat_organizator_tak) {
        this.delegat_organizator_tak = delegat_organizator_tak;
    }

    public List<Korisnik> getDelegati_organizator_tak() {
        return delegati_organizator_tak;
    }

    public void setDelegati_organizator_tak(List<Korisnik> delegati_organizator_tak) {
        this.delegati_organizator_tak = delegati_organizator_tak;
    }

    public boolean isIzbor_igraca_rend_org_tak() {
        return izbor_igraca_rend_org_tak;
    }

    public void setIzbor_igraca_rend_org_tak(boolean izbor_igraca_rend_org_tak) {
        this.izbor_igraca_rend_org_tak = izbor_igraca_rend_org_tak;
    }

    public List<Rekord> getRekordi() {
        return rekordi;
    }

    public void setRekordi(List<Rekord> rekordi) {
        this.rekordi = rekordi;
    }

    public List<Takmicenje> getDelegat_takmicenja() {
        return delegat_takmicenja;
    }

    public void setDelegat_takmicenja(List<Takmicenje> delegat_takmicenja) {
        this.delegat_takmicenja = delegat_takmicenja;
    }

    public int getTrenutno_takmicenje_delegat() {
        return trenutno_takmicenje_delegat;
    }

    public void setTrenutno_takmicenje_delegat(int trenutno_takmicenje_delegat) {
        this.trenutno_takmicenje_delegat = trenutno_takmicenje_delegat;
    }

    public List<String> getLokacije_delegat() {
        return lokacije_delegat;
    }

    public void setLokacije_delegat(List<String> lokacije_delegat) {
        this.lokacije_delegat = lokacije_delegat;
    }

   

    public Date getDelegat_datum() {
        return delegat_datum;
    }

    public void setDelegat_datum(Date delegat_datum) {
        this.delegat_datum = delegat_datum;
    }

    public String getLokacija_trka_delegat() {
        return lokacija_trka_delegat;
    }

    public void setLokacija_trka_delegat(String lokacija_trka_delegat) {
        this.lokacija_trka_delegat = lokacija_trka_delegat;
    }

    public boolean isRender_trka_delegat() {
        return render_trka_delegat;
    }

    public void setRender_trka_delegat(boolean render_trka_delegat) {
        this.render_trka_delegat = render_trka_delegat;
    }

    public List<Trka> getLista_trka_delegat() {
        return lista_trka_delegat;
    }

    public void setLista_trka_delegat(List<Trka> lista_trka_delegat) {
        this.lista_trka_delegat = lista_trka_delegat;
    }

    public boolean isPrvo_logovanje_delegat() {
        return prvo_logovanje_delegat;
    }

    public void setPrvo_logovanje_delegat(boolean prvo_logovanje_delegat) {
        this.prvo_logovanje_delegat = prvo_logovanje_delegat;
    }

    public List<Grupe2x6> getGrupaA_runda1() {
        return grupaA_runda1;
    }

    public void setGrupaA_runda1(List<Grupe2x6> grupaA_runda1) {
        this.grupaA_runda1 = grupaA_runda1;
    }

    public List<Grupe2x6> getGrupaB_runda1() {
        return grupaB_runda1;
    }

    public void setGrupaB_runda1(List<Grupe2x6> grupaB_runda1) {
        this.grupaB_runda1 = grupaB_runda1;
    }

    public List<Grupe2x6> getGrupaA_runda2() {
        return grupaA_runda2;
    }

    public void setGrupaA_runda2(List<Grupe2x6> grupaA_runda2) {
        this.grupaA_runda2 = grupaA_runda2;
    }

    public List<Grupe2x6> getGrupaB_runda2() {
        return grupaB_runda2;
    }

    public void setGrupaB_runda2(List<Grupe2x6> grupaB_runda2) {
        this.grupaB_runda2 = grupaB_runda2;
    }

    public List<Grupe2x6> getGrupaA_runda3() {
        return grupaA_runda3;
    }

    public void setGrupaA_runda3(List<Grupe2x6> grupaA_runda3) {
        this.grupaA_runda3 = grupaA_runda3;
    }

    public List<Grupe2x6> getGrupaB_runda3() {
        return grupaB_runda3;
    }

    public void setGrupaB_runda3(List<Grupe2x6> grupaB_runda3) {
        this.grupaB_runda3 = grupaB_runda3;
    }

    public List<Grupe2x6> getGrupaA_runda4() {
        return grupaA_runda4;
    }

    public void setGrupaA_runda4(List<Grupe2x6> grupaA_runda4) {
        this.grupaA_runda4 = grupaA_runda4;
    }

    public List<Grupe2x6> getGrupaB_runda4() {
        return grupaB_runda4;
    }

    public void setGrupaB_runda4(List<Grupe2x6> grupaB_runda4) {
        this.grupaB_runda4 = grupaB_runda4;
    }

    public List<Grupe2x6> getGrupaA_runda5() {
        return grupaA_runda5;
    }

    public void setGrupaA_runda5(List<Grupe2x6> grupaA_runda5) {
        this.grupaA_runda5 = grupaA_runda5;
    }

    public List<Grupe2x6> getGrupaB_runda5() {
        return grupaB_runda5;
    }

    public void setGrupaB_runda5(List<Grupe2x6> grupaB_runda5) {
        this.grupaB_runda5 = grupaB_runda5;
    }

    public boolean isZakazane_grupe_delegat() {
        return zakazane_grupe_delegat;
    }

    public void setZakazane_grupe_delegat(boolean zakazane_grupe_delegat) {
        this.zakazane_grupe_delegat = zakazane_grupe_delegat;
    }

    
    public boolean[] getTrenutno_stanje_takmicenja() {
        return trenutno_stanje_takmicenja;
    }

    public void setTrenutno_stanje_takmicenja(boolean[] trenutno_stanje_takmicenja) {
        this.trenutno_stanje_takmicenja = trenutno_stanje_takmicenja;
    }

    public List<Grupe2x6> getQ_grupe() {
        return Q_grupe;
    }

    public void setQ_grupe(List<Grupe2x6> Q_grupe) {
        this.Q_grupe = Q_grupe;
    }

    public List<Grupe2x6> getS_grupe() {
        return S_grupe;
    }

    public void setS_grupe(List<Grupe2x6> S_grupe) {
        this.S_grupe = S_grupe;
    }

    public List<Grupe2x6> getM_grupe() {
        return M_grupe;
    }

    public void setM_grupe(List<Grupe2x6> M_grupe) {
        this.M_grupe = M_grupe;
    }

    public boolean isZakazane_grupe_delegat_visa_faza() {
        return zakazane_grupe_delegat_visa_faza;
    }

    public void setZakazane_grupe_delegat_visa_faza(boolean zakazane_grupe_delegat_visa_faza) {
        this.zakazane_grupe_delegat_visa_faza = zakazane_grupe_delegat_visa_faza;
    }

    public List<Integer> getTakmicari_int() {
        return takmicari_int;
    }

    public void setTakmicari_int(List<Integer> takmicari_int) {
        this.takmicari_int = takmicari_int;
    }

    public List<Kup> getKup_mecevi_16() {
        return kup_mecevi_16;
    }

    public void setKup_mecevi_16(List<Kup> kup_mecevi_16) {
        this.kup_mecevi_16 = kup_mecevi_16;
    }

    public List<Kup> getKup_mecevi_8() {
        return kup_mecevi_8;
    }

    public void setKup_mecevi_8(List<Kup> kup_mecevi_8) {
        this.kup_mecevi_8 = kup_mecevi_8;
    }

    public List<Kup> getKup_mecevi_4() {
        return kup_mecevi_4;
    }

    public void setKup_mecevi_4(List<Kup> kup_mecevi_4) {
        this.kup_mecevi_4 = kup_mecevi_4;
    }

    public List<Kup> getKup_mecevi_2() {
        return kup_mecevi_2;
    }

    public void setKup_mecevi_2(List<Kup> kup_mecevi_2) {
        this.kup_mecevi_2 = kup_mecevi_2;
    }

    public List<Kup> getKup_mecevi_1() {
        return kup_mecevi_1;
    }

    public void setKup_mecevi_1(List<Kup> kup_mecevi_1) {
        this.kup_mecevi_1 = kup_mecevi_1;
    }

    public boolean isKup_ekipni() {
        return kup_ekipni;
    }

    public void setKup_ekipni(boolean kup_ekipni) {
        this.kup_ekipni = kup_ekipni;
    }

    public boolean isKup_zakazani_mecevi() {
        return kup_zakazani_mecevi;
    }

    public void setKup_zakazani_mecevi(boolean kup_zakazani_mecevi) {
        this.kup_zakazani_mecevi = kup_zakazani_mecevi;
    }

    public boolean isZavrseno_takmicenje() {
        return zavrseno_takmicenje;
    }

    public void setZavrseno_takmicenje(boolean zavrseno_takmicenje) {
        this.zavrseno_takmicenje = zavrseno_takmicenje;
    }

    public int getKval_broj_grupa() {
        return kval_broj_grupa;
    }

    public void setKval_broj_grupa(int kval_broj_grupa) {
        this.kval_broj_grupa = kval_broj_grupa;
    }

    public String getKval_mask() {
        return kval_mask;
    }

    public void setKval_mask(String kval_mask) {
        this.kval_mask = kval_mask;
    }

    public String getKval_mask_naslov() {
        return kval_mask_naslov;
    }

    public void setKval_mask_naslov(String kval_mask_naslov) {
        this.kval_mask_naslov = kval_mask_naslov;
    }

    public List<Kval_pomocna_termini> getKval_termini_lokacije() {
        return kval_termini_lokacije;
    }

    public void setKval_termini_lokacije(List<Kval_pomocna_termini> kval_termini_lokacije) {
        this.kval_termini_lokacije = kval_termini_lokacije;
    }

    public boolean isKval_zakazane_grupe() {
        return kval_zakazane_grupe;
    }

    public void setKval_zakazane_grupe(boolean kval_zakazane_grupe) {
        this.kval_zakazane_grupe = kval_zakazane_grupe;
    }

    public List<List<Kval>> getKval_grupe() {
        return kval_grupe;
    }

    public void setKval_grupe(List<List<Kval>> kval_grupe) {
        this.kval_grupe = kval_grupe;
    }

    public List<Kval> getKval_finale() {
        return kval_finale;
    }

    public void setKval_finale(List<Kval> kval_finale) {
        this.kval_finale = kval_finale;
    }

    public boolean isKval_zavrsene_kavlifikacije() {
        return kval_zavrsene_kavlifikacije;
    }

    public void setKval_zavrsene_kavlifikacije(boolean kval_zavrsene_kavlifikacije) {
        this.kval_zavrsene_kavlifikacije = kval_zavrsene_kavlifikacije;
    }

    public List<Pom_lista_tak_zem> getModelSportovi() {
        return modelSportovi;
    }

    public void setModelSportovi(List<Pom_lista_tak_zem> modelSportovi) {
        this.modelSportovi = modelSportovi;
    }
    

   
    
    
   
    
    
    
    
    
}
